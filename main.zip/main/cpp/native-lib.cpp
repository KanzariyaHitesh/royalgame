#include <jni.h>
#include <string>

extern "C"
JNIEXPORT jstring JNICALL
Java_com_royalpass_ucpubg_utils_MyApplication_JNIApiUrl(JNIEnv *env,jobject instance) {
    std::string hello = "http://www.kbbinfotech.com/ucpubg/";
    return env->NewStringUTF(hello.c_str());
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_royalpass_ucpubg_utils_MyApplication_JNIPREF(JNIEnv *env, jobject instance) {
    std::string hello ="ucpubg";
    return env->NewStringUTF(hello.c_str());
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_royalpass_ucpubg_utils_MyApplication_JNIZenderNounce(JNIEnv *env,jobject instance) {
    std::string hello = "roupubhfnvy9026754@@";
    return env->NewStringUTF(hello.c_str());
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_royalpass_ucpubg_utils_MyApplication_JNISALT(JNIEnv *env, jobject instance) {
    std::string hello ="ucpubg";
    return env->NewStringUTF(hello.c_str());
}extern "C"
JNIEXPORT jstring JNICALL
Java_com_royalpass_ucpubg_utils_MyApplication_LinkUrl(JNIEnv *env, jobject instance) {
    std::string hello = "http://www.kbbinfotech.com/";
    return env->NewStringUTF(hello.c_str());
}