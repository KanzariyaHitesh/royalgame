package com.royalpass.ucpubg.Activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.royalpass.ucpubg.R;
import com.royalpass.ucpubg.model.ResponceCredit;
import com.royalpass.ucpubg.model.ResponceData;
import com.royalpass.ucpubg.model.User;
import com.royalpass.ucpubg.utils.DataStorage;
import com.royalpass.ucpubg.utils.MyApplication;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Splash_Screen extends AppCompatActivity {

    @BindView(R.id.name)
    EditText NameEditText;
    @BindView(R.id.reffral_code)
    EditText refferalCodeEditText;
    @BindView(R.id.email_id)
    EditText emailEditText;
    @BindView(R.id.head_lay)
    LinearLayout headLayout;
    @BindView(R.id.regi_field)
    LinearLayout regi_field;
    @BindView(R.id.sign_up_lay)
    LinearLayout sign_up_lay;
    @BindView(R.id.dummy)
    View dm;
    ViewGroup rootLayout;
    private ProgressDialog progressDialog;
    LinearLayout linearLayout;
    public static GoogleSignInClient mGoogleSignInClient;
    private LinearLayout ll_email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash__screen);
        ButterKnife.bind(this);
        linearLayout = (LinearLayout) findViewById(R.id.sign_up_lay);
        ll_email = (LinearLayout) findViewById(R.id.ll_email);
        checkExist();
    }

    private void checkExist() {
        if (MyApplication.getDataStorage().registeredUser() != null) {
            askForExtraCredit();
        } else {
            linearLayout.setVisibility(View.VISIBLE);
            ll_email.setVisibility(View.VISIBLE);
        }
        if (progressDialog == null) {
            progressDialog = new ProgressDialog(this);
            progressDialog.setMessage("signing up...");
            progressDialog.setCancelable(false);
        }
        findViewById(R.id.submit_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findViewById(R.id.submit_btn).setEnabled(false);
                register();
            }
        });
        attachKeyboardListeners();
    }

    protected void attachKeyboardListeners() {
        rootLayout = (ViewGroup) findViewById(R.id.error_connection_lay);
        rootLayout.getViewTreeObserver().addOnGlobalLayoutListener(keyboardLayoutListener);
    }


    private ViewTreeObserver.OnGlobalLayoutListener keyboardLayoutListener = new ViewTreeObserver.OnGlobalLayoutListener() {
        @Override
        public void onGlobalLayout() {
            Rect r = new Rect();
            rootLayout.getWindowVisibleDisplayFrame(r);
            int heightDiff = rootLayout.getRootView().getHeight() - (r.bottom - r.top);
            if (heightDiff > 250) {
                //enter your code here
                slideUp(headLayout);
                dm.setVisibility(View.VISIBLE);
            } else {
                //enter code for hid
                slideDown(headLayout);
                dm.setVisibility(View.GONE);
            }
        }
    };

    private void register() {
        if (!validateForm()) {
            findViewById(R.id.submit_btn).setEnabled(true);
            return;
        }
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (null != getCurrentFocus())
            imm.hideSoftInputFromWindow(getCurrentFocus().getApplicationWindowToken(), 0);
        validateEmail();
    }

    private void validateEmail() {
        show();
        MyApplication.getApiInterface().registerDevice(MyApplication.getZN(), MyApplication.getPeshk().trim(), NameEditText.getText().toString()
                , emailEditText.getText().toString(), refferalCodeEditText.getText().toString().toLowerCase()).enqueue(new Callback<ResponceData>() {

            @Override
            public void onResponse(Call<ResponceData> call, retrofit2.Response<ResponceData> response) {
                if (response.code() == 200) {
                    Log.e("responce", new Gson().toJson(response.body()));
                    if (response.body().getSuccess() == 1) {
                        registerAccount();
                    } else {
                        emailEditText.setError("Email already exist");
                        findViewById(R.id.submit_btn).setEnabled(true);
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponceData> call, Throwable t) {
                hide();
                findViewById(R.id.submit_btn).setEnabled(true);

            }
        });
    }

    public void slideUp(final View view) {
        if (view.getVisibility() == View.GONE) {
            return;
        }
        TranslateAnimation animate = new TranslateAnimation(
                0,                 // fromXDelta
                0,                 // toXDelta
                0,  // fromYDelta
                -view.getHeight());                // toYDelta
        animate.setDuration(500);
        animate.setFillAfter(true);
        view.startAnimation(animate);
        view.setVisibility(View.GONE);
    }

    public void slideDown(final View view) {
        if (view.getVisibility() == View.VISIBLE) {
            return;
        }
        view.setVisibility(View.VISIBLE);
        TranslateAnimation animate = new TranslateAnimation(
                0,                 // fromXDelta
                0,                 // toXDelta
                -view.getHeight(),                 // fromYDelta
                0); // toYDelta
        animate.setDuration(500);
        animate.setFillAfter(true);
        view.startAnimation(animate);
    }

    private boolean validateForm() {
        boolean result = true;
        if (TextUtils.isEmpty(NameEditText.getText().toString())) {
            NameEditText.setError("Required");
            result = false;
        } else if (NameEditText.getText().toString().length() < 3) {
            NameEditText.setError("Not Valid");
            result = false;
        } else {
            NameEditText.setError(null);
        }
        if (TextUtils.isEmpty(emailEditText.getText().toString())) {
            emailEditText.setError("Required");
            result = false;
        } else if (!isValidEmail(emailEditText.getText().toString())) {
            emailEditText.setError("Email not valid");
            result = false;
        } else {
            emailEditText.setError(null);
        }
        return result;
    }

    public static boolean isValidEmail(CharSequence target) {
        return (!TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches());
    }

    private void askForExtraCredit() {
        new MyApplication.DBDats(new MyApplication.DataListener() {
            @Override
            public void onDataReceive(Float ucs) {
                ecc(ucs);
            }
        }).execute();

    }

    private void ecc(final Float ucs) {
        Log.e("ecc", MyApplication.getZN() + "\n" + MyApplication.getPeshk().trim() + "\n" + String.valueOf(MyApplication.getDataStorage().registeredUser().getId()) + "\n" + (Float) ucs);
        MyApplication.getApiInterface().upgecc(MyApplication.getZN(), MyApplication.getPeshk(), MyApplication.getDataStorage().registeredUser().getId(), (Float) ucs).enqueue(new Callback<ResponceData>() {
            @Override
            public void onResponse(Call<ResponceData> call, Response<ResponceData> response) {
                hide();
                if (response.code() != 200) {
                    showServerErr(response.code());
                    return;
                }
                if (response.body().getSuccess() != 1) {
                    showUserNotfoundError();
                    return;
                }
                if (response.body().getData() == null) {
                    goToNext();
                    return;
                }
                ResponceCredit responceCredit = new Gson().fromJson(new Gson().toJson(response.body().getData()), ResponceCredit.class);
                MyApplication.setPcc(responceCredit.getUpgcc());
                MyApplication.setbrstatus(responceCredit.getUpgstatus());
                MyApplication.setServerStemp(responceCredit.getCdt());
                MyApplication.setPcc(responceCredit.getUpgcc());
                MyApplication.getApplicationInstance().setlucky_box_id(responceCredit.getLuckyBoxId());
                MyApplication.getApplicationInstance().setupgintru(responceCredit.getUpgintru());
                MyApplication.getApplicationInstance().setupgnative(responceCredit.getUpgnative());
                MyApplication.getApplicationInstance().setupguintru(responceCredit.getUpguintru());
                MyApplication.getApplicationInstance().setupginfobox(responceCredit.getUpginfobox());
                MyApplication.getApplicationInstance().setupginfo(responceCredit.getUpginfo());
                MyApplication.getApplicationInstance().setupginfobtn(responceCredit.getUpginfobtn());
                MyApplication.getApplicationInstance().setupginfolink(responceCredit.getUpginfolink());
                MyApplication.getApplicationInstance().setupginfobtntext(responceCredit.getUpginfobtntext());
                if (responceCredit.getBonusUcs() > 0) {
                    MyApplication.getDataStorage().putbonus_ucs(responceCredit.getBonusUcs(), "EXTRA POINTS");
                }
                if (responceCredit.getUpginfobox() == 1) {
                    showInfoDialog(responceCredit.getUpd(), responceCredit.getVrs());
                } else {
                    askForeUpdate(responceCredit.getUpd(), responceCredit.getVrs());
//                    askForeUpdate(0, responceCredit.getVrs());
                }
            }

            @Override
            public void onFailure(Call<ResponceData> call, Throwable t) {
                hide();
                Snackbar snackbar = Snackbar
                        .make(findViewById(R.id.error_connection_lay), "Something wrong,please try again", Snackbar.LENGTH_INDEFINITE)
                        .setAction("RETRY", new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                ecc(ucs);
                            }
                        })
                        .setActionTextColor(Color.RED);
                View sbView = snackbar.getView();
                TextView textView = (TextView) sbView.findViewById(R.id.snackbar_text);
                textView.setTextColor(Color.YELLOW);
                snackbar.show();
            }
        });
    }

    private void showServerErr(int code) {
        Snackbar snackbar = Snackbar
                .make(findViewById(R.id.error_connection_lay), "Server error " + code, Snackbar.LENGTH_INDEFINITE)
                .setAction("RETRY", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        askForExtraCredit();
                    }
                })
                .setActionTextColor(Color.RED);
        View sbView = snackbar.getView();
        TextView textView = (TextView) sbView.findViewById(R.id.snackbar_text);
        textView.setTextColor(Color.YELLOW);
        snackbar.show();
    }

    private void showUserNotfoundError() {
        MyApplication.getDataStorage().clearData();
        MyApplication.getApplicationInstance().deletedetails();
        MyApplication.getDataStorage().setRegisteredUser(null);
        Snackbar snackbar = Snackbar
                .make(findViewById(R.id.error_connection_lay), "User not found", Snackbar.LENGTH_INDEFINITE)
                .setAction("RETRY", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        checkExist();
                    }
                })
                .setActionTextColor(Color.RED);
        View sbView = snackbar.getView();
        TextView textView = (TextView) sbView.findViewById(R.id.snackbar_text);
        textView.setTextColor(Color.YELLOW);
        snackbar.show();
    }

    private String versionname = "";

    private void askForeUpdate(Integer upd, String playstoreVersionName) {
        try {
            versionname = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            versionname = "1.0.0";
        }
        switch (upd) {
            case 0:
                goToNext();
                break;
            case 1:
                if (!versionname.equals(playstoreVersionName)) {
                    findViewById(R.id.update_lay).setVisibility(View.VISIBLE);
                } else {
                    goToNext();
                }
                break;
            case 2:
                if (!versionname.equals(playstoreVersionName)) {
                    findViewById(R.id.update_lay).setVisibility(View.VISIBLE);
                    findViewById(R.id.no_btn).setVisibility(View.GONE);
                } else {
                    goToNext();
                }
                break;
        }
    }

    public void skip(View view) {
        startActivity(new Intent(Splash_Screen.this, MainActivity.class));
        finish();
    }

    private void registerAccount() {
        MyApplication.getDataStorage().clearData();
        Log.e("register", MyApplication.getZN() + "\n" + MyApplication.getPeshk().trim() + "\n" + NameEditText.getText().toString()
                + "\n" + emailEditText.getText().toString() + "\n" + refferalCodeEditText.getText().toString().toLowerCase());
        MyApplication.getApiInterface().registerDevice(MyApplication.getZN(), MyApplication.getPeshk().trim(), NameEditText.getText().toString()
                , emailEditText.getText().toString(), refferalCodeEditText.getText().toString().toLowerCase()).enqueue(new Callback<ResponceData>() {

            @Override
            public void onResponse(Call<ResponceData> call, retrofit2.Response<ResponceData> response) {
                if (response.code() == 200) {
                    if (response.body().getSuccess() == 1) {
                        if (response.body().getData() != null) {
                            Log.e("data", new Gson().toJson(response.body().getData()));
                            User user = new Gson().fromJson(new Gson().toJson(response.body().getData()), User.class);
                            DataStorage dataStorage = MyApplication.getDataStorage();
                            dataStorage.setRegisteredUser(user);
                            dataStorage.putbonus_ucs(user.getUcs(), "INITIAL POINTS");
                            if (user.getRic() == 1) {
                                dataStorage.putbonus_ucs(Float.valueOf(1000), "INVITATION CODE POINTS");
                            }
//                            MyApplication.getDataStorage().setScratchTime(Long.valueOf(user.getBalloon()));
//                            MyApplication.getDataStorage().checkIn(Long.valueOf(user.getDailyCheckIn()));
                            findViewById(R.id.sign_up_lay).setVisibility(View.GONE);
                            askForExtraCredit();
                        }
                    } else {
                        hide();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponceData> call, Throwable t) {
                showSnak();
                hide();
            }
        });
    }

    private void show() {
        if (progressDialog != null && !progressDialog.isShowing()) {
            progressDialog.show();
        }
    }

    private void hide() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
        findViewById(R.id.submit_btn).setEnabled(true);
    }

    private void viewUrl(String s) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(s));
        String title = "Select Browser";
        Intent chooser = Intent.createChooser(intent, title);
        startActivity(chooser);
    }

    private void showSnak() {
        Snackbar snackbar = Snackbar
                .make(findViewById(R.id.error_connection_lay), "Internet connection either slow or not available. ", Snackbar.LENGTH_INDEFINITE)
                .setAction("RETRY", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        registerAccount();
                    }
                })
                .setActionTextColor(Color.RED);

        View sbView = snackbar.getView();
        TextView textView = (TextView) sbView.findViewById(R.id.snackbar_text);
        textView.setTextColor(Color.YELLOW);
        snackbar.show();
    }

    private void goToNext() {
        startActivity(new Intent(Splash_Screen.this, MainActivity.class));
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public void update(View view) {
        Uri uri = Uri.parse("market://details?id=" + getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_NEW_DOCUMENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
        }
    }

    public void showInfoDialog(final Integer upd, final String vrs) {
        final Dialog dialog = new Dialog(this);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dialog_info);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        TextView txt_infotext = (TextView) dialog.findViewById(R.id.txt_infotext);
        Button btn_infolink = (Button) dialog.findViewById(R.id.btn_infolink);
        Button btn_ok = (Button) dialog.findViewById(R.id.btn_ok);
        Button btn_cancel = (Button) dialog.findViewById(R.id.btn_cancel);

        txt_infotext.setText(MyApplication.getApplicationInstance().getupginfo());
        btn_infolink.setText(MyApplication.getApplicationInstance().getupginfobtntext());

        if (MyApplication.getApplicationInstance().getupginfobtn() == 1) {
            btn_ok.setVisibility(View.VISIBLE);
            btn_cancel.setVisibility(View.VISIBLE);
        } else {
            btn_ok.setVisibility(View.GONE);
            btn_cancel.setVisibility(View.GONE);
        }

        if (MyApplication.getApplicationInstance().getupginfolink().isEmpty()) {
            btn_infolink.setVisibility(View.GONE);
        } else {
            btn_infolink.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse(MyApplication.getApplicationInstance().getupginfolink()));
                    String title = "Select Browser";
                    Intent chooser = Intent.createChooser(intent, title);
                    startActivity(chooser);
                }
            });
        }

        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
                askForeUpdate(upd, vrs);
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
                askForeUpdate(upd, vrs);
            }
        });

        dialog.show();
    }
}