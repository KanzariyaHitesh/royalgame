package com.royalpass.ucpubg.Activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.bumptech.glide.Glide;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdIconView;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.royalpass.ucpubg.R;
import com.royalpass.ucpubg.model.Datum_Participate;
import com.royalpass.ucpubg.model.ResponceData_LuckycardParticipate;
import com.royalpass.ucpubg.model.ResponceData_ParticipateHistory;
import com.royalpass.ucpubg.utils.MyApplication;
import com.unity3d.ads.UnityAds;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Participate extends AppCompatActivity {
    ImageView luckycard;
    TextView titTextView, titleTextView, no_royalhistory, wintxt;
    LinearLayout historyLayout;
    RecyclerView historyRecyclerView;
    SwipeRefreshLayout swipeRefreshLayout;
    ProgressBar progressBar;
    CardView noHistoryView;
    private MainActivity mainActivity = new MainActivity();
    private Adapter adapter;
    ImageView imageView;
    private InterstitialAd interstitialAd;
    private final String TAG = Participate.class.getSimpleName();

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_participate);
        interstitialAd = new InterstitialAd(this, "316916302434631_316917302434531");
//        interstitialAd = new InterstitialAd(this,  "VID_HD_16_9_46S_APP_INSTALL#YOUR_PLACEMENT_ID");
        interstitialAd.loadAd();
        if (MyApplication.getScratchReaveledCountParticipate() == 1) {
//            AdLoader.getAds().ShowFBFirst(this);
            // Set listeners for the Interstitial Ad
            interstitialAd.setAdListener(new InterstitialAdListener() {
                @Override
                public void onInterstitialDisplayed(Ad ad) {
                    // Interstitial ad displayed callback
                    Log.e(TAG, "Interstitial ad displayed.");
                }

                @Override
                public void onInterstitialDismissed(Ad ad) {
                    // Interstitial dismissed callback
                    Log.e(TAG, "Interstitial ad dismissed.");
                }

                @Override
                public void onError(Ad ad, AdError adError) {
                    // Ad error callback
                    Log.e(TAG, "Interstitial ad failed to load: " + adError.getErrorMessage());
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (UnityAds.isReady("video")) {
                                UnityAds.show(Participate.this, "video");
                            }
                        }
                    }, 500);
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    // Interstitial ad is loaded and ready to be displayed
                    Log.d(TAG, "Interstitial ad is loaded and ready to be displayed!");
                    // Show the ad
                    interstitialAd.show();
                }

                @Override
                public void onAdClicked(Ad ad) {
                    // Ad clicked callback
                    Log.d(TAG, "Interstitial ad clicked!");
                }

                @Override
                public void onLoggingImpression(Ad ad) {
                    // Ad impression logged callback
                    Log.d(TAG, "Interstitial ad impression logged!");
                }
            });

        } else if (MyApplication.getScratchReaveledCountParticipate() == 2) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (UnityAds.isReady("video")) {
                        UnityAds.show(Participate.this, "video");
                    }
                }
            }, 500);
        } else if (MyApplication.getScratchReaveledCountParticipate() == 3) {
            MyApplication.setScratchReaveledCountParticipate(0);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (UnityAds.isReady("video")) {
                        UnityAds.show(Participate.this, "video");
                    }
                }
            }, 500);
        }
        Toolbar toolbar = findViewById(R.id.toolbar);
        titleTextView = findViewById(R.id.credits_text);
        titTextView = findViewById(R.id.title_text);
        titTextView.setText(R.string.royal_pass);
        titleTextView.setText(String.format("%.2f", MyApplication.getDataStorage().bonus_ucs()));
        no_royalhistory = findViewById(R.id.text);
        wintxt = (TextView) findViewById(R.id.winroyalpassdate);
        setDate(wintxt);
        imageView = (ImageView) findViewById(R.id.imageview);
        Glide.with(this).asGif().load(R.drawable.preload).into(imageView);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationIcon(R.drawable.backarrow);
        luckycard = (ImageView) findViewById(R.id.luckycard);
        historyLayout = (LinearLayout) findViewById(R.id.history_lay);
        historyRecyclerView = (RecyclerView) findViewById(R.id.history_list);
        swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.refresh_lay);
        progressBar = (ProgressBar) findViewById(R.id.progressbar);
        noHistoryView = (CardView) findViewById(R.id.no_history_lay);
        historyRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        adapter = new Adapter();
        historyRecyclerView.setAdapter(adapter);
        getHistory();
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getHistory();
            }
        });
        luckycard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyApplication.setScratchReaveledCountParticipateNow(MyApplication.getScratchReaveledCountParticipateNow() + 1);
                luckycard.setClickable(false);
                participate_status();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        luckycard.setClickable(true);
                    }
                }, 2000);
            }
        });
    }

    public void setDate(TextView view) {
        Date today = Calendar.getInstance().getTime();//getting date
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");//formating according to my need
        String date = formatter.format(today);
        view.setText(date);
    }

    private void participate_status() {
        Log.e("claim", MyApplication.getZN() + "\n" + MyApplication.getPeshk().trim() + "\n" + String.valueOf(MyApplication.getDataStorage().registeredUser().getId()));
        MyApplication.getApiInterface().upgclrp(MyApplication.getZN(), MyApplication.getPeshk().trim(), String.valueOf(MyApplication.getDataStorage().registeredUser().getId()))
                .enqueue(new Callback<ResponceData_LuckycardParticipate>() {
                    @Override
                    public void onResponse(Call<ResponceData_LuckycardParticipate> call, Response<ResponceData_LuckycardParticipate> response) {
                        if (response.code() == 200) {
                            if (response.body().getData() != null) {
                                Log.e("data", new Gson().toJson(response.body().getData()));
                                String luckycardus = response.body().getMsg();
                                MyApplication.getApplicationInstance().setparticipatemsg(luckycardus);
                                Intent intent = new Intent(getApplicationContext(), ParticipateStatus.class);
                                startActivity(intent);
                            }
                            Log.e("claim_responce", "success");
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponceData_LuckycardParticipate> call, Throwable t) {
                    }
                });
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
//            Intent intent = new Intent();
//            setResult(RESULT_OK, intent);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
//        Intent intent = new Intent();
//        setResult(3, intent);
//        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        updateCredits();
    }

    public void updateCredits() {
        titleTextView.setText(String.format("%.2f", MyApplication.getDataStorage().bonus_ucs()));
    }

    private void getHistory() {
        Log.e("History", MyApplication.getZN() + "\n" + MyApplication.getPeshk());
        MyApplication.getApiInterface().upgwnrph(MyApplication.getZN(), MyApplication.getPeshk()).enqueue(new Callback<ResponceData_ParticipateHistory>() {
            @Override
            public void onResponse(Call<ResponceData_ParticipateHistory> call, Response<ResponceData_ParticipateHistory> response) {
                swipeRefreshLayout.setRefreshing(false);
                progressBar.setVisibility(View.GONE);
                if (response.code() == 200) {
                    if (response.body().getSuccess() == 1) {
                        if (response.body().getData() != null) {
                            noHistoryView.setVisibility(View.GONE);
                            List<Datum_Participate> ClaimBoxHistories = new Gson().fromJson(new Gson().toJson(response.body().getData()), new TypeToken<List<Datum_Participate>>() {
                            }.getType());
                            if (ClaimBoxHistories != null && ClaimBoxHistories.size() > 0) {
                                imageView.setVisibility(View.GONE);
                                adapter.addHistory(ClaimBoxHistories);
                            } else {
                                imageView.setVisibility(View.GONE);
                                no_royalhistory.setText(R.string.no_royal_history);
                                noHistoryView.setVisibility(View.VISIBLE);
                            }
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponceData_ParticipateHistory> call, Throwable t) {
                swipeRefreshLayout.setRefreshing(false);
                progressBar.setVisibility(View.GONE);
                if (mainActivity != null && mainActivity.snackbar != null) {
                    mainActivity.snackbar.show();
                }
            }
        });
    }

    public class Adapter extends RecyclerView.Adapter<Adapter.MyViewHolder> {
        private List<Datum_Participate> ClaimBoxHistories = new ArrayList<>();
        private CardView.LayoutParams layoutParams;

        public Adapter() {
            layoutParams = new CardView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, MyApplication.getDisplay().getHeight() / 9);
        }

        @NonNull
        @Override
        public Adapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            return new Adapter.MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.participatehistory_cardview, viewGroup, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Adapter.MyViewHolder myViewHolder, final int i) {
            myViewHolder.relativeLayout.setLayoutParams(layoutParams);
            myViewHolder.name.setText("" + ClaimBoxHistories.get(i).getName());
            myViewHolder.email.setText("" + ClaimBoxHistories.get(i).getEmail());
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
            myViewHolder.date.setText(simpleDateFormat.format(ClaimBoxHistories.get(i).getWinnerDate()));
        }

        @Override
        public int getItemCount() {
            return ClaimBoxHistories.size();
        }

        public void addHistory(List<Datum_Participate> ClaimBoxHistories) {
            this.ClaimBoxHistories.clear();
            notifyDataSetChanged();
            for (Datum_Participate payoutHistory : ClaimBoxHistories) {
                this.ClaimBoxHistories.add(payoutHistory);
                notifyItemInserted(this.ClaimBoxHistories.size() - 1);
                notifyItemRangeChanged(0, this.ClaimBoxHistories.size());
            }
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            @BindView(R.id.email)
            TextView email;
            @BindView(R.id.name)
            TextView name;
            @BindView(R.id.date)
            TextView date;
            @BindView(R.id.lay_card)
            RelativeLayout relativeLayout;

            public MyViewHolder(@NonNull View itemView) {
                super(itemView);
                ButterKnife.bind(this, itemView);
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (interstitialAd != null) {
            interstitialAd.destroy();
        }
        super.onDestroy();
    }
}