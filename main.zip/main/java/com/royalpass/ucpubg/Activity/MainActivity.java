package com.royalpass.ucpubg.Activity;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.royalpass.ucpubg.R;
import com.royalpass.ucpubg.fragment.HomeFragment;
import com.royalpass.ucpubg.fragment.InviteFragment;
import com.royalpass.ucpubg.fragment.SettingsFragment;
import com.royalpass.ucpubg.model.ResponceData;
import com.royalpass.ucpubg.model.User;
import com.royalpass.ucpubg.utils.AdLoader;
import com.royalpass.ucpubg.utils.MyApplication;
import com.unity3d.ads.IUnityAdsListener;
import com.unity3d.ads.UnityAds;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private HomeFragment homeFragment;
    private SettingsFragment settingsFragment;
    private InviteFragment inviteFragment;
    public Snackbar snackbar;
    private Dialog alertDailog;
    private TextView alertText, titTextView, textView, titleTextView;
    static int frag_setting = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        AdLoader.getAds().loadFullAdFacebook(this);
        final UnityAdsListener myAdsListener = new UnityAdsListener();
        UnityAds.initialize(this, "3282143", myAdsListener);
        frag_setting = getIntent().getIntExtra("move_to_setting", 0);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        navView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        snackbar = Snackbar.make(findViewById(R.id.main_lay), "Not Connecting! Check your connection", Snackbar.LENGTH_LONG);
        View sbView = snackbar.getView();
        textView = (TextView) sbView.findViewById(R.id.snackbar_text);
        textView.setTextColor(Color.RED);
        titTextView = findViewById(R.id.title_text);
        titTextView.setText(getString(R.string.app_title));
        titTextView.setSelected(true);
        titleTextView = findViewById(R.id.credits_text);
        User user = MyApplication.getDataStorage().registeredUser();
        if (user != null) {
            titleTextView.setText(String.format("%.2f", MyApplication.getDataStorage().bonus_ucs()));
        }
        homeFragment = new HomeFragment(getApplicationContext());
        settingsFragment = new SettingsFragment();
        inviteFragment = new InviteFragment();
        loadFragment(new HomeFragment(getApplicationContext()));
        navView.setItemIconTintList(null);
        if (frag_setting == 1) {
            loadFragment(new SettingsFragment());
            frag_setting = 0;
        }
    }

    private class UnityAdsListener implements IUnityAdsListener {

        public void onUnityAdsReady(String placementId) {

        }

        @Override
        public void onUnityAdsStart(String placementId) {
        }

        @Override
        public void onUnityAdsFinish(String placementId, UnityAds.FinishState finishState) {
        }

        @Override
        public void onUnityAdsError(UnityAds.UnityAdsError error, String message) {

        }
    }

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment fragment = null;
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    fragment = homeFragment;
                    titTextView.setText(R.string.app_title);
                    break;
                case R.id.navigation_invite:
                    fragment = inviteFragment;
                    titTextView.setText(R.string.Invite_Friends);
                    break;

                case R.id.navigation_settings:
                    fragment = settingsFragment;
                    titTextView.setText(R.string.title_settings);
                    break;
                case R.id.navigation_share:
                    String url = "http://bit.ly/2WfJKkF";
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("text/plain");
                    shareIntent.putExtra(Intent.EXTRA_TEXT, "Do you want to earn money? \n" +
                            "Download now:" + "\n" + url);
                    startActivity(Intent.createChooser(shareIntent, "Share link using"));
                    break;
            }
            return loadFragment(fragment);
        }
    };

    private boolean loadFragment(Fragment fragment) {
        //switching fragment
        if (fragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commitAllowingStateLoss();
            return true;
        }
        return false;
    }

    public void rateApp() {
        Uri uri = Uri.parse("market://details?id=" + getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_NEW_DOCUMENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        updateCredits();
    }

    public void updateCredits() {
        titleTextView.setText(String.format("%.2f", MyApplication.getDataStorage().bonus_ucs()));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private ImageView alertImage;

    public void setUpDialoge(Context mainActivity) {
        alertDailog = new Dialog(mainActivity);
        alertDailog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        alertDailog.setContentView(R.layout.showalert_dialog);
        alertImage = alertDailog.findViewById(R.id.alert_img);
        alertText = alertDailog.findViewById(R.id.alert_txt);
        alertDailog.findViewById(R.id.close).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDailog.dismiss();
            }
        });
    }

    public void failedAlert(String msg) {
        alertImage.setImageResource(R.drawable.points_icon_large);
        alertText.setText(msg);
        alertDailog.show();
    }

    @Override
    public void onResume() {
        super.onResume();
        titleTextView.setText(String.format("%.2f", MyApplication.getDataStorage().bonus_ucs()));
    }

}