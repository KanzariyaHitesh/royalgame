package com.royalpass.ucpubg.Activity;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdIconView;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.royalpass.ucpubg.R;
import com.royalpass.ucpubg.utils.MyApplication;
import com.unity3d.ads.UnityAds;

import java.util.ArrayList;
import java.util.List;

public class ParticipateStatus extends AppCompatActivity {
    TextView titTextView, titleTextView, participatemsg;
    RelativeLayout relativeLayout;
    ImageView imageView;
    LinearLayout linear_layout;
    private InterstitialAd interstitialAd;
    private final String TAG = ParticipateStatus.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_participate_status);
        interstitialAd = new InterstitialAd(this, "316916302434631_316917302434531");
//        interstitialAd = new InterstitialAd(this,  "VID_HD_16_9_46S_APP_INSTALL#YOUR_PLACEMENT_ID");
        interstitialAd.loadAd();
        if (MyApplication.getScratchReaveledCountParticipateNow() == 1) {
//            AdLoader.getAds().ShowFBFirst(this);
            // Set listeners for the Interstitial Ad
            interstitialAd.setAdListener(new InterstitialAdListener() {
                @Override
                public void onInterstitialDisplayed(Ad ad) {
                    // Interstitial ad displayed callback
                    Log.e(TAG, "Interstitial ad displayed.");
                }

                @Override
                public void onInterstitialDismissed(Ad ad) {
                    // Interstitial dismissed callback
                    Log.e(TAG, "Interstitial ad dismissed.");
                }

                @Override
                public void onError(Ad ad, AdError adError) {
                    // Ad error callback
                    Log.e(TAG, "Interstitial ad failed to load: " + adError.getErrorMessage());
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (UnityAds.isReady("video")) {
                                UnityAds.show(ParticipateStatus.this, "video");
                            }
                        }
                    }, 500);
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    // Interstitial ad is loaded and ready to be displayed
                    Log.d(TAG, "Interstitial ad is loaded and ready to be displayed!");
                    // Show the ad
                    interstitialAd.show();
                }

                @Override
                public void onAdClicked(Ad ad) {
                    // Ad clicked callback
                    Log.d(TAG, "Interstitial ad clicked!");
                }

                @Override
                public void onLoggingImpression(Ad ad) {
                    // Ad impression logged callback
                    Log.d(TAG, "Interstitial ad impression logged!");
                }
            });

        } else if (MyApplication.getScratchReaveledCountParticipateNow() == 2) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (UnityAds.isReady("video")) {
                        UnityAds.show(ParticipateStatus.this, "video");
                    }
                }
            }, 500);
        } else if (MyApplication.getScratchReaveledCountParticipateNow() == 3) {
            MyApplication.setScratchReaveledCountParticipateNow(0);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (UnityAds.isReady("video")) {
                        UnityAds.show(ParticipateStatus.this, "video");
                    }
                }
            }, 500);
        }
        Toolbar toolbar = findViewById(R.id.toolbar);
        Button back_button = (Button) findViewById(R.id.back_now);
        titleTextView = findViewById(R.id.credits_text);
        participatemsg = findViewById(R.id.participatemsg);
        titTextView = findViewById(R.id.title_text);
        titTextView.setText(R.string.royal_pass);
        relativeLayout = findViewById(R.id.relative_prograss);
        linear_layout = findViewById(R.id.linear_layout);
        imageView = (ImageView) findViewById(R.id.imageview);
        Glide.with(this).asGif().load(R.drawable.preload).into(imageView);
        titleTextView.setText(String.format("%.2f", MyApplication.getDataStorage().bonus_ucs()));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationIcon(R.drawable.backarrow);
        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        participatemsg.setText(MyApplication.getApplicationInstance().getparticipatemsg() + "");
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                relativeLayout.setVisibility(View.GONE);
                linear_layout.setVisibility(View.VISIBLE);
            }
        }, 3000);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (interstitialAd != null) {
            interstitialAd.destroy();
        }
        super.onDestroy();
    }
}