package com.royalpass.ucpubg.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdIconView;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.google.android.material.tabs.TabLayout;
import com.royalpass.ucpubg.R;
import com.royalpass.ucpubg.fragment.ViewPagerAdapter;
import com.royalpass.ucpubg.utils.MyApplication;

import java.util.ArrayList;
import java.util.List;

public class Wallet extends AppCompatActivity {
    static TabLayout tabLayout;
    ViewPagerAdapter viewPagerAdapter;
    Toolbar toolbar;
    ViewPager viewPager;
    Button redeem;
    TextView titTextView, titleTextView, ucpoint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallet);
        Toolbar toolbar = findViewById(R.id.toolbar);
        titleTextView = findViewById(R.id.credits_text);
        ucpoint = findViewById(R.id.ucpoint);
        titTextView = findViewById(R.id.title_text);
        redeem = findViewById(R.id.redeem);
        titTextView.setText(R.string.wallet);
        ucpoint.setText(String.format("%.2f", MyApplication.getDataStorage().bonus_ucs()));
        titleTextView.setText(String.format("%.2f", MyApplication.getDataStorage().bonus_ucs()));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationIcon(R.drawable.backarrow);
        viewPager = findViewById(R.id.viewpager);
        viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(viewPagerAdapter);
        tabLayout = (TabLayout) findViewById(R.id.tablayout);
        tabLayout.setTabIndicatorFullWidth(false);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.setTabMode(TabLayout.MODE_FIXED);
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        redeem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Wallet.this, Redeem.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        updateCredits();
    }

    public void updateCredits() {
        titleTextView.setText(String.format("%.2f", MyApplication.getDataStorage().bonus_ucs()));
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public void onResume() {
        super.onResume();
        titleTextView.setText(String.format("%.2f", MyApplication.getDataStorage().bonus_ucs()));
        ucpoint.setText(String.format("%.2f", MyApplication.getDataStorage().bonus_ucs()));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}