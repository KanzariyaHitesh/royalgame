package com.royalpass.ucpubg.Activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.bumptech.glide.Glide;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdIconView;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.royalpass.ucpubg.R;
import com.royalpass.ucpubg.model.Datum_Box;
import com.royalpass.ucpubg.model.ResponceData_LuckyBoxHistory;
import com.royalpass.ucpubg.utils.MyApplication;
import com.unity3d.ads.UnityAds;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LuckyBoxHistory extends AppCompatActivity {
    LinearLayout historyLayout;
    RecyclerView historyRecyclerView;
    SwipeRefreshLayout swipeRefreshLayout;
    ProgressBar progressBar;
    CardView noHistoryView;
    private TextView screentitle, titleTextView, no_textHistory;
    private MainActivity mainActivity = new MainActivity();
    private Adapter adapter;
    ImageView imageView;
    private InterstitialAd interstitialAd;
    private final String TAG = LuckyBoxHistory.class.getSimpleName();

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lucky_box_history);
        interstitialAd = new InterstitialAd(this, "316916302434631_316917302434531");
//        interstitialAd = new InterstitialAd(this,  "VID_HD_16_9_46S_APP_INSTALL#YOUR_PLACEMENT_ID");
        interstitialAd.loadAd();
        if (MyApplication.getScratchReaveledCountBoxHistory() == 1) {
//            AdLoader.getAds().ShowFBFirst(this);

            // Set listeners for the Interstitial Ad
            interstitialAd.setAdListener(new InterstitialAdListener() {
                @Override
                public void onInterstitialDisplayed(Ad ad) {
                    // Interstitial ad displayed callback
                    Log.e(TAG, "Interstitial ad displayed.");
                }

                @Override
                public void onInterstitialDismissed(Ad ad) {
                    // Interstitial dismissed callback
                    Log.e(TAG, "Interstitial ad dismissed.");
                }

                @Override
                public void onError(Ad ad, AdError adError) {
                    // Ad error callback
                    Log.e(TAG, "Interstitial ad failed to load: " + adError.getErrorMessage());
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (UnityAds.isReady("video")) {
                                UnityAds.show(LuckyBoxHistory.this, "video");
                            }
                        }
                    }, 500);
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    // Interstitial ad is loaded and ready to be displayed
                    Log.d(TAG, "Interstitial ad is loaded and ready to be displayed!");
                    // Show the ad
                    interstitialAd.show();
                }

                @Override
                public void onAdClicked(Ad ad) {
                    // Ad clicked callback
                    Log.d(TAG, "Interstitial ad clicked!");
                }

                @Override
                public void onLoggingImpression(Ad ad) {
                    // Ad impression logged callback
                    Log.d(TAG, "Interstitial ad impression logged!");
                }
            });

        } else if (MyApplication.getScratchReaveledCountBoxHistory() == 2) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (UnityAds.isReady("video")) {
                        UnityAds.show(LuckyBoxHistory.this, "video");
                    }
                }
            }, 500);
        } else if (MyApplication.getScratchReaveledCountBoxHistory() >= 3) {
            MyApplication.setScratchReaveledCountBoxHistory(0);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (UnityAds.isReady("video")) {
                        UnityAds.show(LuckyBoxHistory.this, "video");
                    }
                }
            }, 500);
        }
        screentitle = findViewById(R.id.title_text);
        no_textHistory = findViewById(R.id.text);
        screentitle.setText(R.string.BoxHistory);
        Toolbar toolbar = findViewById(R.id.toolbar);
        titleTextView = findViewById(R.id.credits_text);
        imageView = (ImageView) findViewById(R.id.imageview);
        Glide.with(this).asGif().load(R.drawable.preload).into(imageView);
        titleTextView.setText(String.format("%.2f", MyApplication.getDataStorage().bonus_ucs()));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationIcon(R.drawable.backarrow);
        historyLayout = (LinearLayout) findViewById(R.id.history_lay);
        historyRecyclerView = (RecyclerView) findViewById(R.id.history_list);
        swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.refresh_lay);
        progressBar = (ProgressBar) findViewById(R.id.progressbar);
        noHistoryView = (CardView) findViewById(R.id.no_history_lay);
        historyRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        adapter = new Adapter();
        historyRecyclerView.setAdapter(adapter);
        getHistory();
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getHistory();
            }
        });

    }

    private void getHistory() {
        Log.e("History", MyApplication.getZN() + "\n" + MyApplication.getPeshk());
        MyApplication.getApiInterface().upglbh(MyApplication.getZN(), MyApplication.getPeshk()).enqueue(new Callback<ResponceData_LuckyBoxHistory>() {
            @Override
            public void onResponse(Call<ResponceData_LuckyBoxHistory> call, Response<ResponceData_LuckyBoxHistory> response) {
                swipeRefreshLayout.setRefreshing(false);
                progressBar.setVisibility(View.GONE);
                if (response.code() == 200) {
                    if (response.body().getSuccess() == 1) {
                        if (response.body().getData() != null) {
                            noHistoryView.setVisibility(View.GONE);
                            List<Datum_Box> ClaimBoxHistories = new Gson().fromJson(new Gson().toJson(response.body().getData()), new TypeToken<List<Datum_Box>>() {
                            }.getType());
                            if (ClaimBoxHistories != null && ClaimBoxHistories.size() > 0) {
                                imageView.setVisibility(View.GONE);
                                adapter.addHistory(ClaimBoxHistories);
                            } else {
                                imageView.setVisibility(View.GONE);
                                no_textHistory.setText(R.string.no_history);
                                noHistoryView.setVisibility(View.VISIBLE);
                            }
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponceData_LuckyBoxHistory> call, Throwable t) {
                swipeRefreshLayout.setRefreshing(false);
                progressBar.setVisibility(View.GONE);
                if (mainActivity != null && mainActivity.snackbar != null) {
                    mainActivity.snackbar.show();
                }
            }
        });
    }

    public class Adapter extends RecyclerView.Adapter<Adapter.MyViewHolder> {
        private List<Datum_Box> ClaimBoxHistories = new ArrayList<>();
        private CardView.LayoutParams layoutParams;

        public Adapter() {
            layoutParams = new CardView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, MyApplication.getDisplay().getHeight() / 9);
        }

        @NonNull
        @Override
        public Adapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            return new Adapter.MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.luckyboxhistory_cardlayout, viewGroup, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Adapter.MyViewHolder myViewHolder, final int i) {
            myViewHolder.relativeLayout.setLayoutParams(layoutParams);
            myViewHolder.boxid.setText("Box ID: " + ClaimBoxHistories.get(i).getBoxId());
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
            myViewHolder.date.setText(simpleDateFormat.format(ClaimBoxHistories.get(i).getCdt()));
            SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("HH:mm:ss");
            myViewHolder.time.setText(simpleDateFormat1.format(ClaimBoxHistories.get(i).getDailyTimeStamp()));
            myViewHolder.relativeLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(getApplicationContext(), LuckyBoxWinnerHistory.class);
                    intent.putExtra("boxid", ClaimBoxHistories.get(i).getBoxId());
                    startActivity(intent);
                }
            });
        }

        @Override
        public int getItemCount() {
            return ClaimBoxHistories.size();
        }

        public void addHistory(List<Datum_Box> ClaimBoxHistories) {
            this.ClaimBoxHistories.clear();
            notifyDataSetChanged();
            for (Datum_Box payoutHistory : ClaimBoxHistories) {
                this.ClaimBoxHistories.add(payoutHistory);
                notifyItemInserted(this.ClaimBoxHistories.size() - 1);
                notifyItemRangeChanged(0, this.ClaimBoxHistories.size());
            }
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            @BindView(R.id.boxid)
            TextView boxid;
            @BindView(R.id.date)
            TextView date;
            @BindView(R.id.time)
            TextView time;
            @BindView(R.id.lay_card)
            RelativeLayout relativeLayout;

            public MyViewHolder(@NonNull View itemView) {
                super(itemView);
                ButterKnife.bind(this, itemView);
            }
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (interstitialAd != null) {
            interstitialAd.destroy();
        }
        super.onDestroy();
    }
}