package com.royalpass.ucpubg.Activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.gson.Gson;
import com.royalpass.ucpubg.R;
import com.royalpass.ucpubg.model.ResponceData_ClaimBox;
import com.royalpass.ucpubg.utils.MyApplication;
import com.unity3d.ads.UnityAds;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LuckyBox extends AppCompatActivity {
    Button claim_btn, BoxHistory;
    TextView boxid, noofuser, titleTextView;
    private final String TAG = LuckyBox.class.getSimpleName();
    private InterstitialAd interstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lucky_box_winner);
        interstitialAd = new InterstitialAd(this, "316916302434631_316917302434531");
//        interstitialAd = new InterstitialAd(this,  "VID_HD_16_9_46S_APP_INSTALL#YOUR_PLACEMENT_ID");
        interstitialAd.loadAd();
        if (MyApplication.getScratchReaveledCount() == 1) {
//            AdLoader.getAds().ShowFBFirst(this);
            // Set listeners for the Interstitial Ad
            interstitialAd.setAdListener(new InterstitialAdListener() {
                @Override
                public void onInterstitialDisplayed(Ad ad) {
                    // Interstitial ad displayed callback
                    Log.e(TAG, "Interstitial ad displayed.");
                }

                @Override
                public void onInterstitialDismissed(Ad ad) {
                    // Interstitial dismissed callback
                    Log.e(TAG, "Interstitial ad dismissed.");
                }

                @Override
                public void onError(Ad ad, AdError adError) {
                    // Ad error callback
                    Log.e(TAG, "Interstitial ad failed to load: " + adError.getErrorMessage());
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (UnityAds.isReady("video")) {
                                UnityAds.show(LuckyBox.this, "video");
                            }
                        }
                    }, 500);
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    // Interstitial ad is loaded and ready to be displayed
                    Log.d(TAG, "Interstitial ad is loaded and ready to be displayed!");
                    // Show the ad
                    interstitialAd.show();
                }

                @Override
                public void onAdClicked(Ad ad) {
                    // Ad clicked callback
                    Log.d(TAG, "Interstitial ad clicked!");
                }

                @Override
                public void onLoggingImpression(Ad ad) {
                    // Ad impression logged callback
                    Log.d(TAG, "Interstitial ad impression logged!");
                }
            });
        } else if (MyApplication.getScratchReaveledCount() == 2) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (UnityAds.isReady("video")) {
                        UnityAds.show(LuckyBox.this, "video");
                    }
                }
            }, 500);
        } else if (MyApplication.getScratchReaveledCount() >= 3) {
            MyApplication.setScratchReaveledCount(0);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (UnityAds.isReady("video")) {
                        UnityAds.show(LuckyBox.this, "video");
                    }
                }
            }, 500);
        }

        claim_btn = (Button) findViewById(R.id.claim_btn);
        BoxHistory = (Button) findViewById(R.id.box_history);
        boxid = (TextView) findViewById(R.id.boxid);
        noofuser = (TextView) findViewById(R.id.noofuser);
        Toolbar toolbar = findViewById(R.id.toolbar);
        titleTextView = findViewById(R.id.credits_text);
        TextView titTextView = findViewById(R.id.title_text);
        titTextView.setText(R.string.luckybox);
        titleTextView.setText(String.format("%.2f", MyApplication.getDataStorage().bonus_ucs()));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationIcon(R.drawable.backarrow);
        boxid.setText("BOX ID: " + MyApplication.getApplicationInstance().getlucky_box_id());
        claim_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyApplication.setScratchReaveledCountClaim(MyApplication.getScratchReaveledCountClaim() + 1);
                claim_btn.setClickable(false);
                claim_box();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        claim_btn.setClickable(true);
                    }
                }, 2000);
            }
        });
        BoxHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), LuckyBoxHistory.class);
                startActivity(intent);
                MyApplication.setScratchReaveledCountBoxHistory(MyApplication.getScratchReaveledCountBoxHistory() + 1);
            }
        });

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && requestCode == 1) {
//                    Toast.makeText(getApplicationContext(),"ads status "+MyApplication.getApplicationInstance().getbrstatus(),Toast.LENGTH_LONG).show();
            updateCredits();
        }
    }

    private void claim_box() {
        Log.e("claim", MyApplication.getZN() + "\n" + MyApplication.getPeshk().trim() + "\n" + String.valueOf(MyApplication.getDataStorage().registeredUser().getId()));
        MyApplication.getApiInterface().upgcllb(MyApplication.getZN(), MyApplication.getPeshk().trim(), String.valueOf(MyApplication.getDataStorage().registeredUser().getId()))
                .enqueue(new Callback<ResponceData_ClaimBox>() {
                    @Override
                    public void onResponse(Call<ResponceData_ClaimBox> call, Response<ResponceData_ClaimBox> response) {
                        if (response.code() == 200) {
                            if (response.body().getSuccess() == 1) {
                                if (response.body().getData() != null) {
                                    Log.e("data", new Gson().toJson(response.body().getData()));
                                    String luckycardus = response.body().getMsg();
                                    MyApplication.getApplicationInstance().setcliamboxdata(luckycardus);
                                    Intent intent = new Intent(getApplicationContext(), BoxClaim.class);
                                    startActivity(intent);
                                }
                                Log.e("claim_responce", "success");
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponceData_ClaimBox> call, Throwable t) {

                    }
                });
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
//            Intent intent = new Intent();
//            setResult(RESULT_OK, intent);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
//        Intent intent = new Intent();
//        setResult(RESULT_OK, intent);
//        finish();
    }


    public void updateCredits() {
        titleTextView.setText(String.format("%.2f", MyApplication.getDataStorage().bonus_ucs()));
    }

    @Override
    protected void onDestroy() {
        if (interstitialAd != null) {
            interstitialAd.destroy();
        }
        super.onDestroy();
    }
}