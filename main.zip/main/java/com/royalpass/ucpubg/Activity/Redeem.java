package com.royalpass.ucpubg.Activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdIconView;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.royalpass.ucpubg.R;
import com.royalpass.ucpubg.model.ResponceData;
import com.royalpass.ucpubg.utils.MyApplication;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Redeem extends AppCompatActivity {
    RelativeLayout relativeLayout1, relativeLayout2, relativeLayout3, relativeLayout4, relativeLayout5, relativeLayout6, relativeLayout7;
    ProgressBar progressBar;
    private ProgressDialog progressDialog;
    private Dialog redeemCreditDialog;
    private Button cancel, submit;
    private EditText pubg_id;
    static String option_id;
    TextView titTextView, titleTextView, claimbox_data;
    private MainActivity mainActivity = new MainActivity();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_redeem);
        progressBar = (ProgressBar) findViewById(R.id.progressbar);
        Toolbar toolbar = findViewById(R.id.toolbar);
        titleTextView = findViewById(R.id.credits_text);
        titTextView = findViewById(R.id.title_text);
        claimbox_data = findViewById(R.id.ClaimBox_data);
        titTextView.setText(R.string.redeem);
        titleTextView.setText(String.format("%.2f", MyApplication.getDataStorage().bonus_ucs()));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationIcon(R.drawable.backarrow);
        relativeLayout1 = findViewById(R.id.lay_card1);
        relativeLayout2 = findViewById(R.id.lay_card2);
        relativeLayout3 = findViewById(R.id.lay_card3);
        relativeLayout4 = findViewById(R.id.lay_card4);
        relativeLayout5 = findViewById(R.id.lay_card5);
        relativeLayout6 = findViewById(R.id.lay_card6);
        relativeLayout7 = findViewById(R.id.lay_card7);
        relativeLayout1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                option_id = String.valueOf(1e234);
                if (MyApplication.getDataStorage().bonus_ucs() >= 35) {
                    credits = String.valueOf(35);
                    redeemCreditDialog.show();
                } else {
                    mainActivity.setUpDialoge(Redeem.this);
                    mainActivity.failedAlert("Sorry, You have not enough UCs to redeem.");
                }
            }
        });
        relativeLayout2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                option_id = String.valueOf(2e234);
                if (MyApplication.getDataStorage().bonus_ucs() >= 75) {
                    credits = String.valueOf(75);
                    redeemCreditDialog.show();
                } else {
                    mainActivity.setUpDialoge(Redeem.this);
                    mainActivity.failedAlert("Sorry, You have not enough UCs to redeem.");
                }
            }
        });
        relativeLayout3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                option_id = String.valueOf(3e234);
                if (MyApplication.getDataStorage().bonus_ucs() >= 220) {
                    credits = String.valueOf(220);
                    redeemCreditDialog.show();
                } else {
                    mainActivity.setUpDialoge(Redeem.this);
                    mainActivity.failedAlert("Sorry, You have not enough UCs to redeem.");
                }
            }
        });
        relativeLayout4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                option_id = String.valueOf(4e234);
                if (MyApplication.getDataStorage().bonus_ucs() >= 770) {
                    credits = String.valueOf(770);
                    redeemCreditDialog.show();
                } else {
                    mainActivity.setUpDialoge(Redeem.this);
                    mainActivity.failedAlert("Sorry, You have not enough UCs to redeem.");
                }
            }
        });
        relativeLayout5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                option_id = String.valueOf(5e234);
                if (MyApplication.getDataStorage().bonus_ucs() >= 2010) {
                    credits = String.valueOf(2010);
                    redeemCreditDialog.show();
                } else {
                    mainActivity.setUpDialoge(Redeem.this);
                    mainActivity.failedAlert("Sorry, You have not enough UCs to redeem.");
                }
            }
        });
        relativeLayout6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                option_id = String.valueOf(6e234);
                if (MyApplication.getDataStorage().bonus_ucs() >= 4200) {
                    credits = String.valueOf(4200);
                    redeemCreditDialog.show();
                } else {
                    mainActivity.setUpDialoge(Redeem.this);
                    mainActivity.failedAlert("Sorry, You have not enough UCs to redeem.");
                }
            }
        });
        relativeLayout7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                option_id = String.valueOf(7e234);
                if (MyApplication.getDataStorage().bonus_ucs() >= 8750) {
                    credits = String.valueOf(8750);
                    redeemCreditDialog.show();
                } else {
                    mainActivity.setUpDialoge(Redeem.this);
                    mainActivity.failedAlert("Sorry, You have not enough UCs to redeem.");
                }
            }
        });
        setUpDialoge();
    }

    private void redeemCredit() {
        progressBar.setVisibility(View.VISIBLE);
        redeemCreditDialog.dismiss();
        Log.e("report log", MyApplication.getZN() + "\n" + MyApplication.getPeshk() + "\n" + MyApplication.getDataStorage().registeredUser().getId() + "\n" + pubg_id.getText().toString() + "\n" + option_id);
        MyApplication.getApiInterface().upgredeem(MyApplication.getZN(), MyApplication.getPeshk(), MyApplication.getDataStorage().registeredUser().getId(), pubg_id.getText().toString()
                , option_id).enqueue(new Callback<ResponceData>() {
            @Override
            public void onResponse(Call<ResponceData> call, Response<ResponceData> response) {
                progressBar.setVisibility(View.GONE);
                if (response.code() == 200) {
                    if (response.body().getSuccess() == 1) {
                        Float credit = -Float.parseFloat(credits);
                        MyApplication.getDataStorage().putbonus_ucs(credit, "UCS PAYOUT REQUEST");
                        titleTextView.setText(String.format("%.2f", MyApplication.getDataStorage().bonus_ucs()));
                        pubg_id.getText().clear();
                        pubg_id.clearFocus();
                        showAlert("Done", getString(R.string.redeem_success_msg), R.drawable.right);
                    } else {
                        progressBar.setVisibility(View.GONE);
                        showAlert("Failed", getString(R.string.redeem_failed_msg), R.drawable.wrong);
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponceData> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                pubg_id.getText().clear();
                pubg_id.clearFocus();
                if (mainActivity != null && mainActivity.snackbar != null) {
                    mainActivity.snackbar.show();
                }
            }
        });
    }

    private void showAlert(String title, String txt, int res) {
        final Dialog redeemResultDialog = new Dialog(Redeem.this);
        redeemResultDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        redeemResultDialog.setContentView(R.layout.showalert_dialog);
        redeemResultDialog.setCancelable(true);
        TextView msg = redeemResultDialog.findViewById(R.id.alert_txt);
        ImageView icon = redeemResultDialog.findViewById(R.id.alert_img);
        redeemResultDialog.findViewById(R.id.close).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                redeemResultDialog.dismiss();
            }
        });
        icon.setImageResource(res);
        msg.setText(txt);
        redeemResultDialog.show();
    }

    private String credits;

    private void setUpDialoge() {
        redeemCreditDialog = new Dialog(Redeem.this);
        redeemCreditDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        redeemCreditDialog.setContentView(R.layout.new_payout_dialog);
        redeemCreditDialog.setCancelable(true);
        pubg_id = redeemCreditDialog.findViewById(R.id.pubd_id);
        cancel = redeemCreditDialog.findViewById(R.id.cancel);
        submit = redeemCreditDialog.findViewById(R.id.submit);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                redeemCreditDialog.dismiss();
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!pubg_id.getText().toString().isEmpty()) {
                    redeemCredit();
                } else {
                    pubg_id.setError("Enter Valid Pubg Id");
                }
            }
        });

        if (progressDialog == null) {
            progressDialog = new ProgressDialog(Redeem.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setCancelable(false);
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}