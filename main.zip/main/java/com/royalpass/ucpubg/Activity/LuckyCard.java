package com.royalpass.ucpubg.Activity;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.airbnb.lottie.LottieAnimationView;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdIconView;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.google.gson.Gson;
import com.royalpass.ucpubg.R;
import com.royalpass.ucpubg.fragment.HomeFragment;
import com.royalpass.ucpubg.model.ResponceData_ClaimLuckyCard;
import com.royalpass.ucpubg.model.Tsmp;
import com.royalpass.ucpubg.utils.DataStorage;
import com.royalpass.ucpubg.utils.MyApplication;
import com.unity3d.ads.UnityAds;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LuckyCard extends AppCompatActivity {
    TextView titTextView, titleTextView, ucwinner, congo, youearn;
    private InterstitialAd interstitialAd;
    private final String TAG = LuckyCard.class.getSimpleName();

    public LuckyCard() { }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lucky_card);
        interstitialAd = new InterstitialAd(this, "316916302434631_316917302434531");
//        interstitialAd = new InterstitialAd(this, "VID_HD_16_9_46S_APP_INSTALL#YOUR_PLACEMENT_ID");
        interstitialAd.loadAd();
        if (MyApplication.getScratchReaveledCountLuckyCard() == 1) {
//            AdLoader.getAds().ShowFBFirst(this);

            // Set listeners for the Interstitial Ad
            interstitialAd.setAdListener(new InterstitialAdListener() {
                @Override
                public void onInterstitialDisplayed(Ad ad) {
                    // Interstitial ad displayed callback
                    Log.e(TAG, "Interstitial ad displayed.");
                }

                @Override
                public void onInterstitialDismissed(Ad ad) {
                    // Interstitial dismissed callback
                    Log.e(TAG, "Interstitial ad dismissed.");
                }

                @Override
                public void onError(Ad ad, AdError adError) {
                    // Ad error callback
                    Log.e(TAG, "Interstitial ad failed to load: " + adError.getErrorMessage());
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (UnityAds.isReady("video")) {
                                UnityAds.show(LuckyCard.this, "video");
                            }
                        }
                    }, 500);
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    // Interstitial ad is loaded and ready to be displayed
                    Log.d(TAG, "Interstitial ad is loaded and ready to be displayed!");
                    // Show the ad
                    interstitialAd.show();
                }

                @Override
                public void onAdClicked(Ad ad) {
                    // Ad clicked callback
                    Log.d(TAG, "Interstitial ad clicked!");
                }

                @Override
                public void onLoggingImpression(Ad ad) {
                    // Ad impression logged callback
                    Log.d(TAG, "Interstitial ad impression logged!");
                }
            });
        } else if (MyApplication.getScratchReaveledCountLuckyCard() == 2) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (UnityAds.isReady("video")) {
                        UnityAds.show(LuckyCard.this, "video");
                    }
                }
            }, 500);
        } else if (MyApplication.getScratchReaveledCountLuckyCard() == 3) {
            MyApplication.setScratchReaveledCountLuckyCard(0);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (UnityAds.isReady("video")) {
                        UnityAds.show(LuckyCard.this, "video");
                    }
                }
            }, 500);
        }
        Toolbar toolbar = findViewById(R.id.toolbar);
        ucwinner = findViewById(R.id.ucwinner);
        titleTextView = findViewById(R.id.credits_text);
        congo = findViewById(R.id.congratulation);
        youearn = findViewById(R.id.youearn);
        titTextView = findViewById(R.id.title_text);
        titTextView.setText(R.string.luckycard);
        titleTextView.setText(String.format("%.2f", MyApplication.getDataStorage().bonus_ucs()));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationIcon(R.drawable.backarrow);
        congo.setVisibility(View.GONE);
        ucwinner.setVisibility(View.GONE);
        youearn.setVisibility(View.GONE);
        claim_luckycarduc();
        checkIn();
    }

    private void checkIn() {
        ucwinner = findViewById(R.id.ucwinner);
        LottieAnimationView lottieAnimationView = findViewById(R.id.check_in_anim);
        lottieAnimationView.setAnimation("giftbox.json");
        lottieAnimationView.playAnimation();
        lottieAnimationView.loop(false);
        lottieAnimationView.addAnimatorListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                congo.setVisibility(View.VISIBLE);
                youearn.setVisibility(View.VISIBLE);
                ucwinner.setVisibility(View.VISIBLE);
                ucwinner.setText(MyApplication.getApplicationInstance().getgetuc() + " uc");
                updateCredits();
            }
        });
    }

    public void updateCredits() {
        titleTextView.setText(String.format("%.2f", MyApplication.getDataStorage().bonus_ucs()));
    }

    private void claim_luckycarduc() {
        Log.e("claim", MyApplication.getZN() + "\n" + MyApplication.getPeshk().trim() + "\n" + String.valueOf(MyApplication.getDataStorage().registeredUser().getId()));
        MyApplication.getApiInterface().upglkcd(MyApplication.getZN(), MyApplication.getPeshk().trim(), String.valueOf(MyApplication.getDataStorage().registeredUser().getId()))
                .enqueue(new Callback<ResponceData_ClaimLuckyCard>() {
                    @Override
                    public void onResponse(Call<ResponceData_ClaimLuckyCard> call, Response<ResponceData_ClaimLuckyCard> response) {
                        if (response.code() == 200) {
                            if (response.body().getSuccess() == 1) {
                                if (response.body().getData() != null) {
                                    Log.e("data", new Gson().toJson(response.body().getData()));
                                    Tsmp tsmp = new Gson().fromJson(new Gson().toJson(response.body().getTsmp()), Tsmp.class);
                                    DataStorage dataStorage = MyApplication.getDataStorage();
                                    dataStorage.setTsmpUser(tsmp);
                                    MyApplication.setServerStemp(tsmp.getCdt());
                                    Float luckycardus = response.body().getData();
                                    MyApplication.setLuckyCardTime(tsmp.getUserLastClaim());
                                    MyApplication.getApplicationInstance().setUserLastClaim(tsmp.getUserLastClaim());
                                    MyApplication.getApplicationInstance().setgetuc(response.body().getData());
                                    MyApplication.getDataStorage().putbonus_ucs(Float.parseFloat(String.format("%.2f", luckycardus)), "Add Ucs In Wallet");
                                    refresh();
                                }
                            } else {
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponceData_ClaimLuckyCard> call, Throwable t) {

                    }
                });
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            Intent intent = new Intent();
            setResult(RESULT_OK, intent);
            finish();
            HomeFragment homeFragment = new HomeFragment(getApplicationContext());
            homeFragment.isResumed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        HomeFragment homeFragment = new HomeFragment(getApplicationContext());
        homeFragment.isResumed();
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        finish();
    }

    public void refresh() {          //refresh is onClick name given to the button
        onRestart();
    }

    @Override
    protected void onRestart() {
        // TODO Auto-generated method stub
        super.onRestart();
        titleTextView.setText(String.format("%.2f", MyApplication.getDataStorage().bonus_ucs()));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        updateCredits();
    }

    @Override
    protected void onDestroy() {
        if (interstitialAd != null) {
            interstitialAd.destroy();
        }
        super.onDestroy();
    }
}