package com.royalpass.ucpubg.Activity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdIconView;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.royalpass.ucpubg.R;
import com.royalpass.ucpubg.model.Datum_refferallist;
import com.royalpass.ucpubg.model.Response_ReferralList;
import com.royalpass.ucpubg.utils.MyApplication;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ReferralList extends AppCompatActivity {
    LinearLayout historyLayout;
    RecyclerView historyRecyclerView;
    SwipeRefreshLayout swipeRefreshLayout;
    ProgressBar progressBar;
    CardView noHistoryView;
    private TextView titleTextView, textView;
    private MainActivity mainActivity = new MainActivity();
    private Adapter adapter;

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_referral_list);
        TextView screentitle = findViewById(R.id.title_text);
        screentitle.setText(R.string.your_referral_list);
        textView = (TextView) findViewById(R.id.text);
        textView.setText(R.string.empty_referral_list);
        Toolbar toolbar = findViewById(R.id.toolbar);
        titleTextView = findViewById(R.id.credits_text);
        titleTextView.setText(String.format("%.2f", MyApplication.getDataStorage().bonus_ucs()));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationIcon(R.drawable.backarrow);
        historyLayout = (LinearLayout) findViewById(R.id.history_lay);
        historyRecyclerView = (RecyclerView) findViewById(R.id.history_list);
        swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.refresh_lay);
        progressBar = (ProgressBar) findViewById(R.id.progressbar);
        noHistoryView = (CardView) findViewById(R.id.no_history_lay);
        historyRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        adapter = new Adapter();
        historyRecyclerView.setAdapter(adapter);
        getHistory();
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getHistory();
            }
        });
    }

    private void getHistory() {
        Log.e("Referrallist", MyApplication.getZN() + "\n" + MyApplication.getPeshk() + "\n" + MyApplication.getDataStorage().registeredUser().getId());
        MyApplication.getApiInterface().upgrl(MyApplication.getZN(), MyApplication.getPeshk(), MyApplication.getDataStorage().registeredUser().getId()).enqueue(new Callback<Response_ReferralList>() {
            @Override
            public void onResponse(Call<Response_ReferralList> call, Response<Response_ReferralList> response) {
                swipeRefreshLayout.setRefreshing(false);
                progressBar.setVisibility(View.GONE);
                if (response.code() == 200) {
                    if (response.body().getSuccess() == 1) {
                        if (response.body().getData() != null) {
                            List<Datum_refferallist> referral_lists = new Gson().fromJson(new Gson().toJson(response.body().getData()), new TypeToken<List<Datum_refferallist>>() {
                            }.getType());
                            if (referral_lists != null && referral_lists.size() > 0) {
                                adapter.addHistory(referral_lists);
                            } else {
                                historyRecyclerView.setVisibility(View.GONE);
                                noHistoryView.setVisibility(View.VISIBLE);
                            }
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<Response_ReferralList> call, Throwable t) {
                swipeRefreshLayout.setRefreshing(false);
                progressBar.setVisibility(View.GONE);
                if (mainActivity != null && mainActivity.snackbar != null) {
                    mainActivity.snackbar.show();
                }
            }
        });
    }

    public class Adapter extends RecyclerView.Adapter<Adapter.MyViewHolder> {
        private List<Datum_refferallist> referralLists = new ArrayList<>();
        private CardView.LayoutParams layoutParams;

        public Adapter() {
            if (referralLists == null) {
                historyLayout.setVisibility(View.VISIBLE);
            }
            layoutParams = new CardView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, MyApplication.getDisplay().getHeight() / 9);
        }

        @NonNull
        @Override
        public Adapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            return new Adapter.MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.refrrellist_cardview, viewGroup, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Adapter.MyViewHolder myViewHolder, final int i) {
            myViewHolder.relativeLayout.setLayoutParams(layoutParams);
            myViewHolder.referral_list_no.setText(String.valueOf(i + 1));
            myViewHolder.name_refferal.setText(referralLists.get(i).getName());
            myViewHolder.email_refferal.setText(referralLists.get(i).getEmail());
        }

        @Override
        public int getItemCount() {
            return referralLists.size();
        }

        public void addHistory(List<Datum_refferallist> referral_lists) {
            this.referralLists.clear();
            notifyDataSetChanged();
            for (Datum_refferallist referral_list : referral_lists) {
                this.referralLists.add(referral_list);
                notifyItemInserted(this.referralLists.size() - 1);
                notifyItemRangeChanged(0, this.referralLists.size());
            }
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            @BindView(R.id.name_refferal)
            TextView name_refferal;
            @BindView(R.id.email_refferal)
            TextView email_refferal;
            @BindView(R.id.lay_card)
            RelativeLayout relativeLayout;
            @BindView(R.id.referral_list_no)
            TextView referral_list_no;

            public MyViewHolder(@NonNull View itemView) {
                super(itemView);
                ButterKnife.bind(this, itemView);
            }
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}