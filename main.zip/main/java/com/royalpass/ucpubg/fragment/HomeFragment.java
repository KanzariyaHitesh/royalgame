package com.royalpass.ucpubg.fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKeys;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdIconView;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.royalpass.ucpubg.Activity.LuckyBox;
import com.royalpass.ucpubg.Activity.LuckyCard;
import com.royalpass.ucpubg.Activity.MainActivity;
import com.royalpass.ucpubg.Activity.Participate;
import com.royalpass.ucpubg.R;
import com.royalpass.ucpubg.utils.MyApplication;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import butterknife.ButterKnife;

public class HomeFragment extends Fragment {
    private View view;
    Context context;
    static final long START_TIME_IN_MILLIS = 600000;
    boolean mTimerRunning;
    ImageView luckybox, luckycard, participatecard, rate_us;
    TextView wintxt, luckycardtime;
    String NEW_TIMER_START = "new_timer_start";
    public long mLeftTimeInMillis;
    private long mEndTime;
    private CountDownTimer mCountDownTimer;

    String masterKeyAlias;
    { try { masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC);
        } catch (GeneralSecurityException e) { e.printStackTrace();
        } catch (IOException e) { e.printStackTrace(); }
    }
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    public HomeFragment(Context context) {
        this.context=context;
        try { sharedPreferences = EncryptedSharedPreferences.create("secret_shared_prefs", masterKeyAlias, context,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
        } catch (GeneralSecurityException e) { e.printStackTrace();
        } catch (IOException e) { e.printStackTrace(); }
        editor = sharedPreferences.edit();
    }

    @SuppressLint("WrongConstant")
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view == null) {
            view = inflater.inflate(R.layout.layout_home_fragment, container, false);
            ButterKnife.bind(this, view);
            wintxt = (TextView) view.findViewById(R.id.winroyalpassdate);
            luckycardtime = (TextView) view.findViewById(R.id.luckycardtime);
            luckybox = (ImageView) view.findViewById(R.id.luckyboxcard);
            luckycard = (ImageView) view.findViewById(R.id.luckycard);
            participatecard = (ImageView) view.findViewById(R.id.winroyalpasscard);
            rate_us = (ImageView) view.findViewById(R.id.rate_us);
            setDate(wintxt);
            luckybox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    MyApplication.setScratchReaveledCount(MyApplication.getScratchReaveledCount() + 1);
                    Intent intent = new Intent(getContext(), LuckyBox.class);
                    startActivity(intent);
                }
            });
            luckycard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    MyApplication.setScratchReaveledCountLuckyCard(MyApplication.getScratchReaveledCountLuckyCard() + 1);
                    Intent intent = new Intent(getContext(), LuckyCard.class);
                    startActivity(intent);
                    startTime();
                    refresh();
                }
            });
            luckycardtime.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    MyApplication.setScratchReaveledCountLuckyCard(MyApplication.getScratchReaveledCountLuckyCard() + 1);
                    Intent intent = new Intent(getContext(), LuckyCard.class);
                    startActivity(intent);
                    startTime();
                    refresh();
                }
            });
            participatecard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    MyApplication.setScratchReaveledCountParticipate(MyApplication.getScratchReaveledCountParticipate() + 1);
                    Intent intent = new Intent(getContext(), Participate.class);
                    startActivity(intent);
                }
            });
            rate_us.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ((MainActivity) getActivity()).rateApp();
                }
            });
        }

        return view;
    }

    public void setDate(TextView view) {
        Date today = Calendar.getInstance().getTime();//getting date
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");//formating according to my need
        String date = formatter.format(today);
        view.setText(date);
    }

    public void startTime() {
        long currentTimeMillis = System.currentTimeMillis();
        long j = this.mLeftTimeInMillis;
        this.mEndTime = currentTimeMillis + j;
        CountDownTimer r2 = new CountDownTimer(j, 1000) {
            public void onTick(long j) {
                Log.d("OnTickCall: ", String.valueOf(j));
                HomeFragment.this.mLeftTimeInMillis = j;
                HomeFragment.this.updateCountDownText();
                luckycard.setClickable(false);
                MyApplication.getDataStorage().setBoolean(NEW_TIMER_START, true);
                String str = "check";
                if (MyApplication.getDataStorage().getBoolean(str)) {
                    MyApplication.getDataStorage().setBoolean(str, false);
                }
            }

            public void onFinish() {
                luckycardtime.setText("GET CARD");
                luckycardtime.setClickable(true);
                HomeFragment.this.mLeftTimeInMillis = HomeFragment.START_TIME_IN_MILLIS;
                HomeFragment.this.mTimerRunning = false;
                MyApplication.getDataStorage().setBoolean(NEW_TIMER_START, false);
                luckycard.setClickable(true);
            }
        };
        this.mCountDownTimer = r2.start();
        this.mTimerRunning = true;
    }


    @Override
    public void onResume() {
        super.onResume();
    }

    /* access modifiers changed from: private */
    public void updateCountDownText() {
        long j = this.mLeftTimeInMillis;
        int i = (int) ((j / 1000) / 60);
        int i2 = (int) ((j / 1000) % 60);
        String format = String.format(Locale.getDefault(), "%02d:%02d", new Object[]{Integer.valueOf(i), Integer.valueOf(i2)});
        if (MyApplication.getDataStorage().getBoolean(NEW_TIMER_START)) {
            StringBuilder sb = new StringBuilder();
            sb.append(format);
            sb.append("");
            luckycardtime.setClickable(false);
            luckycardtime.setText(sb.toString());
            return;
        }
//        this.binding.btngetcard.setBackgroundResource(R.C1055drawable.btngetcard);
    }

    public void onStart() {
        super.onStart();
        this.mLeftTimeInMillis = sharedPreferences.getLong("millisLeft", START_TIME_IN_MILLIS);
        this.mTimerRunning = sharedPreferences.getBoolean("timerRunning", false);
        Log.i("CallMethod", "OnStart Call");
        MyApplication.getDataStorage().setBoolean("check", true);
        updateCountDownText();
        if (this.mTimerRunning) {
            this.mEndTime = sharedPreferences.getLong("endTime", 0);
            this.mLeftTimeInMillis = this.mEndTime - System.currentTimeMillis();
            if (this.mLeftTimeInMillis < 0) {
                this.mLeftTimeInMillis = 0;
                this.mTimerRunning = false;
                startTime();
                return;
            }
            startTime();
            return;
        }
    }

    public void onStop() {
        super.onStop();
        Log.e("TAG", "onStop: Activity");
        editor.putLong("millisLeft", this.mLeftTimeInMillis);
        editor.putBoolean("timerRunning", this.mTimerRunning);
        editor.putLong("endTime", this.mEndTime);
        editor.apply();
        CountDownTimer countDownTimer = this.mCountDownTimer;
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
    }

    public void refresh() {
        getFragmentManager().beginTransaction().detach(this).attach(this).commit();
    }
}