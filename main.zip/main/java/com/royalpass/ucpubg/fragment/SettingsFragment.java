package com.royalpass.ucpubg.fragment;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.royalpass.ucpubg.Activity.FAQsActivity;
import com.royalpass.ucpubg.Activity.MainActivity;
import com.royalpass.ucpubg.Activity.Splash_Screen;
import com.royalpass.ucpubg.Activity.Wallet;
import com.royalpass.ucpubg.Activity.WebActivity;
import com.royalpass.ucpubg.R;
import com.royalpass.ucpubg.model.Edit_Profile;
import com.royalpass.ucpubg.model.ResponceData;
import com.royalpass.ucpubg.utils.DataStorage;
import com.royalpass.ucpubg.utils.MyApplication;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SettingsFragment extends Fragment {
    static String editname, editemail;
    TextView User_Name, User_Email;
    private Dialog dialog;
    private ProgressDialog progressDialog;
    private MainActivity mainActivity = new MainActivity();
    LinearLayout linearLayout;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.settings_layout, container, false);
        User_Name = view.findViewById(R.id.User_Name);
        User_Email = view.findViewById(R.id.User_Email);
        linearLayout = view.findViewById(R.id.error_connection_lay);
        int count = MyApplication.getDataStorage().getedit_profile();
        if (count == 1) {
            editname = MyApplication.getDataStorage().Editprofile().getName();
            editemail = MyApplication.getDataStorage().Editprofile().getEmail();
        }

        view.findViewById(R.id.wallet).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Wallet.class);
                startActivity(intent);
            }
        });
        view.findViewById(R.id.how_payout_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), FAQsActivity.class);
                startActivity(intent);
            }
        });
        view.findViewById(R.id.privact_policy).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent p_intent = new Intent(getActivity(), WebActivity.class);
                p_intent.putExtra("url", MyApplication.getLinkUrl() + "privacy_policy.html");
                startActivity(p_intent);
            }
        });
        view.findViewById(R.id.terms_condition).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent p_intent = new Intent(getActivity(), WebActivity.class);
                p_intent.putExtra("url", MyApplication.getLinkUrl() + "terms_of_use.html");
                startActivity(p_intent);
            }
        });
        view.findViewById(R.id.edit_profile).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDailog.show();

            }
        });
        view.findViewById(R.id.delete_account).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.show();
            }
        });
        view.findViewById(R.id.rate_us).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity) getActivity()).rateApp();
            }
        });
        setUpDialoge();
        setUpDialoge(getContext());
        return view;
    }

    private void showAlert(String title, String msg) {
        AlertDialog.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            builder = new AlertDialog.Builder(getContext(), android.R.style.Theme_DeviceDefault_Light_Dialog_Alert);
        } else {
            builder = new AlertDialog.Builder(getContext());
        }
        if (builder != null) {
            builder.setTitle(title)
                    .setMessage(msg)
                    .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .show();
        }
    }

    private void Edit_Profile() {
        EditText name_dialog = alertDailog.findViewById(R.id.username);
        EditText email_dialog = alertDailog.findViewById(R.id.useremail);
        MyApplication.getApiInterface().EditProfile(MyApplication.getZN(), MyApplication.getPeshk().trim(), String.valueOf(MyApplication.getDataStorage().registeredUser().getId())
                , name_dialog.getText().toString(), email_dialog.getText().toString()).enqueue(new Callback<ResponceData>() {
            @Override
            public void onResponse(Call<ResponceData> call, Response<ResponceData> response) {
                if (response.code() == 200) {
                    if (response.body().getSuccess() == 1) {
                        if (response.body().getData() != null) {
                            Log.e("data", new Gson().toJson(response.body().getData()));
                            Edit_Profile edit_profile = new Gson().fromJson(new Gson().toJson(response.body().getData()), Edit_Profile.class);
                            DataStorage dataStorage = MyApplication.getDataStorage();
                            dataStorage.setEditprofile(edit_profile);
                            MyApplication.getDataStorage().setedit_profile(1);
                            Toast.makeText(getContext(), "Profile updated successfully", Toast.LENGTH_LONG).show();
                            hide();
                            alertDailog.dismiss();
                            refresh();
                        }
                    } else {
                        hide();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponceData> call, Throwable t) {
                showSnak();
                hide();
            }
        });
    }

    private void showSnak() {
        Snackbar snackbar = Snackbar
                .make(linearLayout, "Internet connection either slow or not available. ", Snackbar.LENGTH_INDEFINITE)
                .setAction("RETRY", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Edit_Profile();
                    }
                })
                .setActionTextColor(Color.RED);

        View sbView = snackbar.getView();
        TextView textView = (TextView) sbView.findViewById(R.id.snackbar_text);
        textView.setTextColor(Color.YELLOW);
        snackbar.show();
    }

    private void show() {
        if (progressDialog != null && !progressDialog.isShowing()) {
            progressDialog.show();
        }
    }

    private void hide() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
        alertDailog.findViewById(R.id.submit).setEnabled(true);
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        int name = MyApplication.getDataStorage().getedit_profile();
        EditText name_dialog = alertDailog.findViewById(R.id.username);
        EditText email_dialog = alertDailog.findViewById(R.id.useremail);
        if (name == 1) {
            editname = MyApplication.getDataStorage().Editprofile().getName();
            editemail = MyApplication.getDataStorage().Editprofile().getEmail();
        }
        if (editemail != null || editname != null) {
            User_Name.setText(editname);
            User_Email.setText(editemail);
            name_dialog.setText(editname);
            email_dialog.setText(editemail);
        } else {
            User_Name.setText(MyApplication.getDataStorage().registeredUser().getName());
            User_Email.setText(MyApplication.getDataStorage().registeredUser().getEmail());
            name_dialog.setText(MyApplication.getDataStorage().registeredUser().getName());
            email_dialog.setText(MyApplication.getDataStorage().registeredUser().getEmail());
        }
    }

    private void setUpDialoge() {
        dialog = new Dialog(getContext());
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.setContentView(R.layout.delete_user_dialog);
        dialog.findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.findViewById(R.id.delete).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                delete_user();
//                splash_screen.signOut();
            }
        });
    }

    private void delete_user() {
        Log.e("Referrallist", MyApplication.getZN() + "\n" + MyApplication.getPeshk() + "\n" + MyApplication.getDataStorage().registeredUser().getId());
        MyApplication.getApiInterface().DeleteProfile(MyApplication.getZN(), MyApplication.getPeshk(), MyApplication.getDataStorage().registeredUser().getId()).enqueue(new Callback<ResponceData>() {
            @Override
            public void onResponse(Call<ResponceData> call, Response<ResponceData> response) {
                if (response.code() == 200) {
                    if (response.body().getSuccess() == 1) {
                        if (response.body().getData() != null) {
                            MyApplication.getDataStorage().clearData();
                            MyApplication.getApplicationInstance().deletedetails();
                            MyApplication.getDataStorage().setRegisteredUser(null);
                            dialog.findViewById(R.id.delete).setClickable(false);
                            dialog.findViewById(R.id.cancel).setClickable(false);
                            Intent intent = new Intent(getActivity(), Splash_Screen.class);
                            startActivity(intent);
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponceData> call, Throwable t) {
                if (mainActivity != null && mainActivity.snackbar != null) {
                    mainActivity.snackbar.show();
                }
            }
        });
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            // Refresh your fragment here
            getFragmentManager().beginTransaction().detach(this).attach(this).commit();
            Log.i("IsRefresh", "Yes");
        }
    }

    private Dialog alertDailog;

    public void setUpDialoge(Context mainActivity) {
        alertDailog = new Dialog(mainActivity);
        alertDailog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        alertDailog.setContentView(R.layout.edituserprofile_dialog);
        EditText UserName = (EditText) alertDailog.findViewById(R.id.username);
        EditText UserEmail = (EditText) alertDailog.findViewById(R.id.useremail);
        if (editemail != null || editname != null) {
            UserName.setText(editname);
            UserEmail.setText(editemail);
        } else {
            UserName.setText(MyApplication.getDataStorage().registeredUser().getName());
            UserEmail.setText(MyApplication.getDataStorage().registeredUser().getEmail());
        }
        UserName.setSelection(UserName.getText().length());
        UserEmail.setSelection(UserEmail.getText().length());
        alertDailog.findViewById(R.id.submit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show();
                if (progressDialog == null) {
                    progressDialog = new ProgressDialog(getContext());
                    progressDialog.setMessage("Profile Updating...");
                    progressDialog.setCancelable(false);
                }
                Edit_Profile();
            }
        });
        alertDailog.findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDailog.dismiss();
                refresh();
            }
        });
    }

    void refresh() {
        getFragmentManager().beginTransaction().detach(this).attach(this).commit();
    }
}