package com.royalpass.ucpubg.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.royalpass.ucpubg.Activity.MainActivity;
import com.royalpass.ucpubg.R;
import com.royalpass.ucpubg.model.RedeemHistory;
import com.royalpass.ucpubg.model.RedeemTransation;
import com.royalpass.ucpubg.model.ResponseData_TransationRedeem;
import com.royalpass.ucpubg.utils.MyApplication;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RedeemHistoryFragment extends androidx.fragment.app.Fragment {

    LinearLayout historyLayout;
    RecyclerView historyRecyclerView;
    SwipeRefreshLayout swipeRefreshLayout;
    ProgressBar progressBar;
    CardView noHistoryView;
    ImageView imageView;
    private MainActivity mainActivity = new MainActivity();
    private Adapter adapter;
    RelativeLayout relativeLayout;

    @SuppressLint("WrongConstant")
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.redeemhistory_layout, container, false);
        historyLayout = (LinearLayout) view.findViewById(R.id.history_lay);
        historyRecyclerView = (RecyclerView) view.findViewById(R.id.history_list);
        swipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.refresh_lay);
        progressBar = (ProgressBar) view.findViewById(R.id.progressbar);
        noHistoryView = (CardView) view.findViewById(R.id.no_history_lay);
        imageView = (ImageView) view.findViewById(R.id.imageview);
        relativeLayout = view.findViewById(R.id.relative_prograss);
        Glide.with(this).asGif().load(R.drawable.preload).into(imageView);
        historyRecyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        adapter = new Adapter();
        historyRecyclerView.setAdapter(adapter);
        getHistory();
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getHistory();
            }
        });
        return view;
    }

    private void getHistory() {
        relativeLayout.setVisibility(View.VISIBLE);
        Log.e("RedeemHistory", MyApplication.getZN() + "\n" + MyApplication.getPeshk() + "\n" + MyApplication.getDataStorage().registeredUser().getId());
        MyApplication.getApiInterface().upgredeemlist(MyApplication.getZN(), MyApplication.getPeshk(), MyApplication.getDataStorage().registeredUser().getId()).enqueue(new Callback<ResponseData_TransationRedeem>() {
            @Override
            public void onResponse(Call<ResponseData_TransationRedeem> call, Response<ResponseData_TransationRedeem> response) {
                swipeRefreshLayout.setRefreshing(false);
                progressBar.setVisibility(View.GONE);
                if (response.code() == 200) {
                    if (response.body().getSuccess() == 1) {
                        if (response.body().getData() != null) {
                            noHistoryView.setVisibility(View.GONE);
                            RedeemTransation redeemTransation = new Gson().fromJson(new Gson().toJson(response.body().getData()), RedeemTransation.class);
                            List<RedeemHistory> eatList = redeemTransation.getRedeemHistory();
                            if (eatList != null && eatList.size() > 0) {
                                relativeLayout.setVisibility(View.GONE);
                                adapter.addHistory(eatList);
                            } else {
                                relativeLayout.setVisibility(View.GONE);
                                noHistoryView.setVisibility(View.VISIBLE);
                            }
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseData_TransationRedeem> call, Throwable t) {
                swipeRefreshLayout.setRefreshing(false);
                progressBar.setVisibility(View.GONE);
                if (mainActivity != null && mainActivity.snackbar != null) {
                    mainActivity.snackbar.show();
                }
            }
        });
    }

    public class Adapter extends RecyclerView.Adapter<Adapter.MyViewHolder> {
        private List<RedeemHistory> ClaimBoxHistories = new ArrayList<>();
        private CardView.LayoutParams layoutParams;

        public Adapter() {
            layoutParams = new CardView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, MyApplication.getDisplay().getHeight() / 9);
        }

        @NonNull
        @Override
        public Adapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            return new Adapter.MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.redeemhistory_cardview, viewGroup, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Adapter.MyViewHolder myViewHolder, final int i) {
            myViewHolder.relativeLayout.setLayoutParams(layoutParams);
            Double optionid = ClaimBoxHistories.get(i).getOptionId();
            if (optionid == 1.0E234) {
                myViewHolder.ucs.setText("35");
            } else if (optionid == 2.0E234) {
                myViewHolder.ucs.setText("75");
            } else if (optionid == 3.0E234) {
                myViewHolder.ucs.setText("220");
            } else if (optionid == 4.0E234) {
                myViewHolder.ucs.setText("770");
            } else if (optionid == 5.0E234) {
                myViewHolder.ucs.setText("2010");
            } else if (optionid == 6.0E234) {
                myViewHolder.ucs.setText("4200");
            } else if (optionid == 7.0E234) {
                myViewHolder.ucs.setText("8750");
            }
            myViewHolder.pubg_id.setText("Pubg Id: " + ClaimBoxHistories.get(i).getPubgId());
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
            myViewHolder.date_time.setText(simpleDateFormat.format(ClaimBoxHistories.get(i).getCreatedDate()));
            Integer st = ClaimBoxHistories.get(i).getStatus();
            if (st == 0) {
                myViewHolder.status.setText("Pending");
            } else if (st == 2) {
                myViewHolder.status.setText("Complete");
            }
        }

        @Override
        public int getItemCount() {
            return ClaimBoxHistories.size();
        }

        public void addHistory(List<RedeemHistory> ClaimBoxHistories) {
            this.ClaimBoxHistories.clear();
            notifyDataSetChanged();
            for (RedeemHistory payoutHistory : ClaimBoxHistories) {
                this.ClaimBoxHistories.add(payoutHistory);
                notifyItemInserted(this.ClaimBoxHistories.size() - 1);
                notifyItemRangeChanged(0, this.ClaimBoxHistories.size());
            }
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {

            @BindView(R.id.ucs)
            TextView ucs;
            @BindView(R.id.pubg_id)
            TextView pubg_id;
            @BindView(R.id.status)
            TextView status;
            @BindView(R.id.date_time)
            TextView date_time;
            @BindView(R.id.lay_card)
            RelativeLayout relativeLayout;

            public MyViewHolder(@NonNull View itemView) {
                super(itemView);
                ButterKnife.bind(this, itemView);
            }
        }
    }
}