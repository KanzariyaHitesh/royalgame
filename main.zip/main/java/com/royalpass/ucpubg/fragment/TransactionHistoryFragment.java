package com.royalpass.ucpubg.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.royalpass.ucpubg.Activity.MainActivity;
import com.royalpass.ucpubg.R;
import com.royalpass.ucpubg.model.CreditHistory;
import com.royalpass.ucpubg.model.RedeemTransation;
import com.royalpass.ucpubg.model.ResponseData_TransationRedeem;
import com.royalpass.ucpubg.utils.MyApplication;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TransactionHistoryFragment extends androidx.fragment.app.Fragment {
    LinearLayout historyLayout;
    RecyclerView historyRecyclerView;
    SwipeRefreshLayout swipeRefreshLayout;
    ProgressBar progressBar;
    CardView noHistoryView;
    ImageView imageView;
    private MainActivity mainActivity = new MainActivity();
    private Adapter adapter;
    TextView no_TransactionHistory;
    RelativeLayout relativeLayout;

    @SuppressLint("WrongConstant")
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.redeemhistory_layout, container, false);
        historyLayout = (LinearLayout) view.findViewById(R.id.history_lay);
        historyRecyclerView = (RecyclerView) view.findViewById(R.id.history_list);
        swipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.refresh_lay);
        progressBar = (ProgressBar) view.findViewById(R.id.progressbar);
        noHistoryView = (CardView) view.findViewById(R.id.no_history_lay);
        relativeLayout = view.findViewById(R.id.relative_prograss);
        imageView = (ImageView) view.findViewById(R.id.imageview);
        Glide.with(this).asGif().load(R.drawable.preload).into(imageView);
        no_TransactionHistory = view.findViewById(R.id.text);
        historyRecyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        adapter = new Adapter();
        historyRecyclerView.setAdapter(adapter);
        getHistory();
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getHistory();
            }
        });
        return view;
    }

    private void getHistory() {
        relativeLayout.setVisibility(View.VISIBLE);
        Log.e("RedeemHistory", MyApplication.getZN() + "\n" + MyApplication.getPeshk() + "\n" + MyApplication.getDataStorage().registeredUser().getId());
        MyApplication.getApiInterface().upgredeemlist(MyApplication.getZN(), MyApplication.getPeshk(), MyApplication.getDataStorage().registeredUser().getId()).enqueue(new Callback<ResponseData_TransationRedeem>() {
            @Override
            public void onResponse(Call<ResponseData_TransationRedeem> call, Response<ResponseData_TransationRedeem> response) {
                swipeRefreshLayout.setRefreshing(false);
                progressBar.setVisibility(View.GONE);
                if (response.code() == 200) {
                    if (response.body().getSuccess() == 1) {
                        if (response.body().getData() != null) {
                            noHistoryView.setVisibility(View.GONE);
                            RedeemTransation redeemTransation = new Gson().fromJson(new Gson().toJson(response.body().getData()), RedeemTransation.class);
                            List<CreditHistory> eatList = redeemTransation.getCreditHistory();
                            if (eatList != null && eatList.size() > 0) {
                                relativeLayout.setVisibility(View.GONE);
                                adapter.addHistory(eatList);
                            } else {
                                relativeLayout.setVisibility(View.GONE);
                                no_TransactionHistory.setText(R.string.no_tansac_history);
                                noHistoryView.setVisibility(View.VISIBLE);
                            }
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseData_TransationRedeem> call, Throwable t) {
                swipeRefreshLayout.setRefreshing(false);
                progressBar.setVisibility(View.GONE);
                if (mainActivity != null && mainActivity.snackbar != null) {
                    mainActivity.snackbar.show();
                }
            }
        });
    }

    public class Adapter extends RecyclerView.Adapter<Adapter.MyViewHolder> {
        private List<CreditHistory> ClaimBoxHistories = new ArrayList<>();
        private CardView.LayoutParams layoutParams;

        public Adapter() {
            layoutParams = new CardView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, MyApplication.getDisplay().getHeight() / 9);
        }

        @NonNull
        @Override
        public Adapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            return new Adapter.MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.transctoinhistory_cardview, viewGroup, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Adapter.MyViewHolder myViewHolder, final int i) {
            myViewHolder.relativeLayout.setLayoutParams(layoutParams);
            myViewHolder.ucs.setText("" + ClaimBoxHistories.get(i).getUcs());
            myViewHolder.details.setText("" + ClaimBoxHistories.get(i).getDetails());
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
            myViewHolder.date.setText(simpleDateFormat.format(ClaimBoxHistories.get(i).getCdt()));
        }

        @Override
        public int getItemCount() {
            return ClaimBoxHistories.size();
        }

        public void addHistory(List<CreditHistory> ClaimBoxHistories) {
            this.ClaimBoxHistories.clear();
            notifyDataSetChanged();
            for (CreditHistory payoutHistory : ClaimBoxHistories) {
                this.ClaimBoxHistories.add(payoutHistory);
                notifyItemInserted(this.ClaimBoxHistories.size() - 1);
                notifyItemRangeChanged(0, this.ClaimBoxHistories.size());
            }
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {

            @BindView(R.id.ucs)
            TextView ucs;
            @BindView(R.id.date)
            TextView date;
            @BindView(R.id.details)
            TextView details;
            @BindView(R.id.lay_card)
            RelativeLayout relativeLayout;

            public MyViewHolder(@NonNull View itemView) {
                super(itemView);
                ButterKnife.bind(this, itemView);
            }
        }
    }
}