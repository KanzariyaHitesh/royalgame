package com.royalpass.ucpubg.fragment;

import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.royalpass.ucpubg.Activity.ReferralList;
import com.royalpass.ucpubg.R;
import com.royalpass.ucpubg.utils.MyApplication;

public class InviteFragment extends Fragment {
    int temp = 0;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.invite_layout, container, false);
        TextView textView = (TextView) view.findViewById(R.id.t2);
        textView.setText(MyApplication.getDataStorage().registeredUser().getReferralCode().toUpperCase());
        view.findViewById(R.id.copy_text).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager cm = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setText(textView.getText());
                Toast.makeText(getContext(), "Copied to clipboard", Toast.LENGTH_SHORT).show();
            }
        });
        view.findViewById(R.id.invite_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                view.findViewById(R.id.invite_btn).setClickable(false);
                shareApp();
                if (temp == 0) {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            view.findViewById(R.id.invite_btn).setClickable(true);
                            temp = 1;
                        }
                    }, 2000);
                }else {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            view.findViewById(R.id.invite_btn).setClickable(true);
                        }
                    }, 1000);
                }
            }
        });
        view.findViewById(R.id.referal_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ReferralList.class);
                startActivity(intent);
            }
        });
        return view;
    }

    private void shareApp() {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT, R.string.app_name);
            String sAux = "Hey, I am invite you to use my referral code [" + MyApplication.getDataStorage().registeredUser().getReferralCode().toUpperCase() + "] during registration and join me on Get Royal Pass & UC PubG app and get instant 2 UCs." +
                    "\n\nDownload Now:\n http://bit.ly/2Np2NmL";
            i.putExtra(Intent.EXTRA_TEXT, sAux);
            Html.fromHtml(sAux);
            startActivity(Intent.createChooser(i, "Invite Via"));
        } catch (Exception e) {
        }
    }
}