package com.royalpass.ucpubg.utils;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.unity3d.ads.UnityAds;

public class AdLoader {

    public static AdLoader adLoader;

    public static AdLoader getAds() {

        if (adLoader == null) {
            adLoader = new AdLoader();
        }
        return adLoader;
    }

    private InterstitialAd interstitialAd;

    public void loadFullAdFacebook(final Context context) {

        try {
//            interstitialAd = new InterstitialAd(context,  "VID_HD_16_9_46S_APP_INSTALL#YOUR_PLACEMENT_ID");
            interstitialAd = new InterstitialAd(context,  "316916302434631_316917302434531");
            interstitialAd.loadAd();
            interstitialAd.setAdListener(new InterstitialAdListener() {
                @Override
                public void onInterstitialDisplayed(Ad ad) {

                }

                @Override
                public void onInterstitialDismissed(Ad ad) {
                }

                @Override
                public void onError(Ad ad, AdError adError) {

                }

                @Override
                public void onAdLoaded(Ad ad) {

                }

                @Override
                public void onAdClicked(Ad ad) {

                }

                @Override
                public void onLoggingImpression(Ad ad) {

                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void ShowFBFirst(Activity context) {

        try {
            if (!ShowFBAds(context)) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (UnityAds.isReady("video")) {
                            UnityAds.show(context, "video");
                        }
                    }
                }, 500);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean ShowFBAds(Context context) {
        boolean isLoad = false;
        try {

            if (interstitialAd!=null && interstitialAd.isAdLoaded()) {
                interstitialAd.show();
                isLoad = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        loadFullAdFacebook(context);
        return isLoad;
    }
}