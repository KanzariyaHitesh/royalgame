package com.royalpass.ucpubg.utils;

import android.provider.BaseColumns;

public class ReaderContract {
    public ReaderContract() {
    }

    /* Inner class that defines the table contents */
    public static abstract class Entry implements BaseColumns {
        public static final String TABLE_NAME = "royal_pass";
        public static final String COLUMN_NAME_ENTRY_ID = "pass_id";
        public static final String COLUMN_COMMENT = "comment";
        public static final String COLUMN_POINT = "point";
        public static final String COLUMN_CREATED_DATE = "created_date";
        public static final String MILLISLEFT = "millisLeft";
        public static final String TIMERRUNNING = "timerRunning";
        public static final String ENDTIME = "endTime";
    }
}