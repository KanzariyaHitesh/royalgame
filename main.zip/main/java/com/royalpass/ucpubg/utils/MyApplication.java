package com.royalpass.ucpubg.utils;

import android.app.Application;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.database.Cursor;
import android.os.AsyncTask;
import android.util.Base64;
import android.view.Display;
import android.view.WindowManager;
import androidx.multidex.MultiDex;
import com.facebook.ads.AdSettings;
import com.facebook.ads.AudienceNetworkAds;
import com.royalpass.ucpubg.Api.ApiClient;
import com.royalpass.ucpubg.Api.ApiInterface;
import net.sqlcipher.database.SQLiteDatabase;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class MyApplication extends Application {
    private static MyApplication myApplicationInstance;
    private static ApiInterface apiInterface;
    private static DataStorage dataStorage;
    private static Display display;
    private float tcl = 0;

    static {
        System.loadLibrary("native-lib");
    }

    private static int scratchReaveledCount = 0;
    private static int scratchReaveledCount_claim = 0;
    private static int scratchReaveledCount_boxhistory = 0;
    private static int scratchReaveledCount_luckycard = 0;
    private static int scratchReaveledCount_participate = 0;
    private static int scratchReaveledCount_participatenow = 0;

    public static int getScratchReaveledCount() {
        return scratchReaveledCount;
    }

    public static void setScratchReaveledCount(int scratchReaveledCount) {
        MyApplication.scratchReaveledCount = scratchReaveledCount;
    }

    public static int getScratchReaveledCountClaim() {
        return scratchReaveledCount_claim;
    }

    public static void setScratchReaveledCountClaim(int scratchReaveledCount_claim) {
        MyApplication.scratchReaveledCount_claim = scratchReaveledCount_claim;
    }

    public static int getScratchReaveledCountBoxHistory() {
        return scratchReaveledCount_boxhistory;
    }

    public static void setScratchReaveledCountBoxHistory(int scratchReaveledCount_boxhistory) {
        MyApplication.scratchReaveledCount_boxhistory = scratchReaveledCount_boxhistory;
    }

    public static int getScratchReaveledCountLuckyCard() {
        return scratchReaveledCount_luckycard;
    }

    public static void setScratchReaveledCountLuckyCard(int scratchReaveledCount_luckycard) {
        MyApplication.scratchReaveledCount_luckycard = scratchReaveledCount_luckycard;
    }

    public static int getScratchReaveledCountParticipate() {
        return scratchReaveledCount_participate;
    }

    public static void setScratchReaveledCountParticipate(int scratchReaveledCount_participate) {
        MyApplication.scratchReaveledCount_participate = scratchReaveledCount_participate;
    }

    public static int getScratchReaveledCountParticipateNow() {
        return scratchReaveledCount_participatenow;
    }

    public static void setScratchReaveledCountParticipateNow(int scratchReaveledCount_participatenow) {
        MyApplication.scratchReaveledCount_participatenow = scratchReaveledCount_participatenow;
    }

    private Integer pcc = 0;

    public static void setPcc(Integer pcc) {
        getApplicationInstance().pcc = pcc;

    }

    public int getPcc() {
        return pcc;
    }

    private int brstatus;

    public int getbrstatus() {
        return brstatus;
    }

    public static void setbrstatus(int brstatus) {
        getApplicationInstance().brstatus = brstatus;
    }


    public static DataStorage getDataStorage() {
        return dataStorage;
    }

    public static ApiInterface getApiInterface() {
        return apiInterface;
    }

    public static String getBU() {
        return getApplicationInstance().JNIApiUrl();
    }

    public static String getZN() {
        return getApplicationInstance().JNIZenderNounce();
    }

    public static String prefN() {
        return getApplicationInstance().JNIPREF();
    }

    //    public static String preDC() { return getApplicationInstance().JNIDAILYCHECKIN(); }
    public static void setServerStemp(Long serverStemp) {
        /*MyApplication.serverStemp = serverStemp;*/
        MyApplication.currentStemp = serverStemp / 1000;
        getApplicationInstance().startTimer();
    }

    public static void setLuckyCardTime(Long serverStemp) {
        /*MyApplication.serverStemp = serverStemp;*/
        MyApplication.currentStemp = serverStemp / 1000;
        getApplicationInstance().startTimer();
    }

    public static Float getTcl() {
        return getApplicationInstance().tcl;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        myApplicationInstance = this;
        AudienceNetworkAds.isInAdsProcess(this);
        AudienceNetworkAds.initialize(this);
        AdSettings.addTestDevice(" rKXuEL3y1+Iw9VXO6BkxBPe8YBM=");
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        dataStorage = new DataStorage(MyApplication.this);
        WindowManager windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        display = windowManager.getDefaultDisplay();
        SQLiteDatabase.loadLibs(this);
        printHashKey();
        new DBDats(null).execute();
    }

    private String peshk;

    public static void printHashKey() {
        try {
            PackageInfo info = getApplicationInstance().getPackageManager().getPackageInfo(getApplicationInstance().getPackageName(), PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                getApplicationInstance().peshk = new String(Base64.encode(md.digest(), 0));
            }
        } catch (NoSuchAlgorithmException e) {
        } catch (Exception e) {
        }
    }

    public static String getPeshk() {
        return getApplicationInstance().peshk.trim();
    }

    public void insertSthToDb(String comment, Float credit) {
        SQLiteDatabase db = DbHelper.getInstance(this).getWritableDatabase(JNISALT());
        ContentValues values = new ContentValues();
        values.put(ReaderContract.Entry.COLUMN_COMMENT, comment);
        values.put(ReaderContract.Entry.COLUMN_POINT, String.valueOf(credit));
        values.put(ReaderContract.Entry.COLUMN_CREATED_DATE, String.valueOf(currentStemp));
        db.insert(ReaderContract.Entry.TABLE_NAME, null, values);
        db.close();
        tcl = tcl + credit;
    }

    public int deletedetails() {
        SQLiteDatabase db = DbHelper.getInstance(this).getWritableDatabase(JNISALT());
        return db.delete(ReaderContract.Entry.TABLE_NAME, null, null);
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }

    public static boolean checkDates(Long timestemp) {
        if (current() >= timestemp) {
            if (!convertDate(current()).equals(convertDate(timestemp))) {
                return true;
            }
        }
        return false;
    }

    public static Long current() {
        return currentStemp;
    }

    private static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");

    public static String convertDate(Long timestemp) {
        return simpleDateFormat.format(new Date(timestemp * 1000));
    }

    public static Long convertStemp(Long date) throws ParseException {
        long epoch = simpleDateFormat.parse(convertDate(date)).getTime() / 1000;
        return epoch;
    }

    public static Display getDisplay() {
        return display;
    }

    public static MyApplication getApplicationInstance() {
        return myApplicationInstance;
    }

    public static class DBDats extends AsyncTask<Void, Void, Float> {
        private DataListener dataListener;

        public DBDats(DataListener dataListener) {
            this.dataListener = dataListener;
        }

        @Override
        protected void onPostExecute(Float integer) {
            super.onPostExecute(integer);
            getApplicationInstance().tcl = integer;
            if (dataListener != null) {
                dataListener.onDataReceive(integer);
            }
        }

        @Override
        protected Float doInBackground(Void... voids) {
            SQLiteDatabase db = DbHelper.getInstance(getApplicationInstance()).getReadableDatabase(getApplicationInstance().JNISALT());
            Cursor cursor = db.rawQuery("SELECT * FROM '" + ReaderContract.Entry.TABLE_NAME + "';", null);
            float creditcount = 0;
            if (cursor != null) {
                if (cursor.moveToFirst()) {
                    do {
                        creditcount += Float.parseFloat(cursor.getString(cursor.getColumnIndex(ReaderContract.Entry.COLUMN_POINT)));
                    } while (cursor.moveToNext());
                }
            }
            cursor.close();
            db.close();
            return creditcount;
        }
    }

    public static boolean compareWithCurrent(Long timestamp) {
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        Long current = current() * 1000;
        timestamp = timestamp * 1000;
        String currentDate = formatter.format(new Date(current));
        String timeDate = formatter.format(new Date(timestamp));

        if (current >= timestamp) {
            if (!currentDate.equalsIgnoreCase(timeDate)) {
                return true;
            }
        }
        return false;
    }

    private static Long currentStemp = 0L;
    private Timer timer;

    private void startTimer() {
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                currentStemp += 1;
            }
        }, 1000, 1000);
    }

    public interface DataListener {
        void onDataReceive(Float data);
    }

    public static String getLinkUrl() {
        return getApplicationInstance().LinkUrl();
    }

    private native String JNIApiUrl();

    private native String JNIZenderNounce();

    //    private native String JNISLS();
    private native String JNISALT();

    private native String LinkUrl();

    private native String JNIPREF();
//    private native String JNIDAILYCHECKIN();


    private Integer ucs;

    public Integer getucs() {
        return ucs;
    }

    public void setucs(Integer brinfobtn) {
        this.ucs = brinfobtn;
    }

    private String upgintru;
    private String upgnative;
    private String upguintru;
    private Integer upginfobox;
    private String upginfo;
    private Integer upginfobtn;
    private String upginfolink;
    private String upginfobtntext;
    private Integer lucky_box_id;
    private Float getuc;
    private Long UserLastClaim;
    private String cliamboxdata;
    private String participatemsg;

    public String getupgintru() {
        return upgintru;
//        return "VID_HD_16_9_46S_APP_INSTALL#YOUR_PLACEMENT_ID";
    }

    public void setupgintru(String upgintru) {
        this.upgintru = upgintru;
    }

    public String getupgnative() {
//            return "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID";
            return upgnative;
    }

    public void setupgnative(String upgnative) {
        this.upgnative = upgnative;
    }

    public Integer getupginfobox() {
        return upginfobox;
    }

    public void setupginfobox(Integer upginfobox) {
        this.upginfobox = upginfobox;
    }

    public String getupguintru() {
        return upguintru;
    }

    public void setupguintru(String upguintru) {
        this.upguintru = upguintru;
    }

    public String getupginfo() {
        return upginfo;
    }

    public void setupginfo(String upginfo) {
        this.upginfo = upginfo;
    }

    public String getupginfolink() {
        return upginfolink;
    }

    public void setupginfolink(String upginfolink) {
        this.upginfolink = upginfolink;
    }

    public String getupginfobtntext() {
        return upginfobtntext;
    }

    public void setupginfobtntext(String upginfobtntext) {
        this.upginfobtntext = upginfobtntext;
    }

    public Integer getupginfobtn() {
        return upginfobtn;
    }

    public void setupginfobtn(Integer upginfobtn) {
        this.upginfobtn = upginfobtn;
    }

    public Integer getlucky_box_id() {
        return lucky_box_id;
    }

    public void setlucky_box_id(Integer lucky_box_id) {
        this.lucky_box_id = lucky_box_id;
    }

    public Float getgetuc() {
        return getuc;
    }

    public void setgetuc(Float getuc) {
        this.getuc = getuc;
    }

    public String getcliamboxdata() {
        return cliamboxdata;
    }

    public void setcliamboxdata(String cliamboxdata) {
        this.cliamboxdata = cliamboxdata;
    }

    public String getparticipatemsg() {
        return participatemsg;
    }

    public void setparticipatemsg(String participatemsg) {
        this.participatemsg = participatemsg;
    }

    public Long getUserLastClaim() {
        return UserLastClaim;
    }

    public void setUserLastClaim(Long UserLastClaim) {
        this.UserLastClaim = UserLastClaim;
    }
}