package com.royalpass.ucpubg.utils;

import android.content.Context;
import net.sqlcipher.database.SQLiteDatabase;
import net.sqlcipher.database.SQLiteOpenHelper;

public class DbHelper extends SQLiteOpenHelper {
    private static DbHelper instance;
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "pubguc.db";

    private static final String TEXT_TYPE = " TEXT";
    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + ReaderContract.Entry.TABLE_NAME + " (" +
                    ReaderContract.Entry._ID + " INTEGER PRIMARY KEY," +
                    ReaderContract.Entry.COLUMN_COMMENT + TEXT_TYPE + "," +
                    ReaderContract.Entry.COLUMN_POINT + TEXT_TYPE + "," +
                    ReaderContract.Entry.COLUMN_CREATED_DATE + TEXT_TYPE +","+
                    ReaderContract.Entry.MILLISLEFT + TEXT_TYPE + "," +
                    ReaderContract.Entry.TIMERRUNNING + TEXT_TYPE + "," +
                    ReaderContract.Entry.ENDTIME + TEXT_TYPE +
                    " )";

    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + ReaderContract.Entry.TABLE_NAME;


    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    static public synchronized DbHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DbHelper(context);
        }
        return instance;
    }

    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }
}