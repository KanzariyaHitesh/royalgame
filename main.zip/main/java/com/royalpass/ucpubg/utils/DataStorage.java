package com.royalpass.ucpubg.utils;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKeys;
import com.google.gson.Gson;
import com.royalpass.ucpubg.model.Edit_Profile;
import com.royalpass.ucpubg.model.Tsmp;
import com.royalpass.ucpubg.model.User;
import java.io.IOException;
import java.security.GeneralSecurityException;

public class DataStorage {
    String masterKeyAlias;
    { try { masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC);
        } catch (GeneralSecurityException e) { e.printStackTrace();
        } catch (IOException e) { e.printStackTrace(); }
    }
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    public DataStorage(Context context) {
        try { sharedPreferences = EncryptedSharedPreferences.create("secret_shared_prefs", masterKeyAlias, context,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
        } catch (GeneralSecurityException e) { e.printStackTrace();
        } catch (IOException e) { e.printStackTrace();
        }
        editor = sharedPreferences.edit();
    }

    public void putbonus_ucs(Float bonus_ucs, String comment) {
        if (bonus_ucs == 0.00) {
            return;
        }
        editor.putFloat("bonus_ucs", bonus_ucs() + bonus_ucs);
        editor.apply();
        if (comment != null) {
            MyApplication.getApplicationInstance().insertSthToDb(comment, bonus_ucs);
        }
    }

    public Float bonus_ucs() {
        return sharedPreferences.getFloat("bonus_ucs", 0);
    }

    public void setRegisteredUser(User user) {
        editor.putString("user_config", (new Gson().toJson(user)));
        editor.apply();
    }

    public User registeredUser() {
        if (sharedPreferences.getString("user_config", null) != null) {
            return new Gson().fromJson(sharedPreferences.getString("user_config", null), User.class);
        }
        return null;
    }

    public void setTsmpUser(Tsmp tsmp) {
        editor.putString("user_tsmp", (new Gson().toJson(tsmp)));
        editor.apply();
    }

    public Tsmp getTsmpUser() {
        if (sharedPreferences.getString("user_tsmp", null) != null) {
            return new Gson().fromJson(sharedPreferences.getString("user_tsmp", null), Tsmp.class);
        }
        return null;
    }

    public void setEditprofile(Edit_Profile editprofile) {
        editor.putString("edit_user", (new Gson().toJson(editprofile)));
        editor.apply();
    }

    public Edit_Profile Editprofile() {
        if (sharedPreferences.getString("edit_user", null) != null) {
            return new Gson().fromJson(sharedPreferences.getString("edit_user", null), Edit_Profile.class);
        }
        return null;
    }

    public void setedit_profile(int photo) {
        editor.putInt("edit_profile_pubg", photo);
        editor.apply();
    }

    public int getedit_profile() {
        return sharedPreferences.getInt("edit_profile_pubg", 0);
    }

    public void setBoolean(String str, boolean z) {
        editor.putBoolean(str, z);
        editor.apply();
    }

    public boolean getBoolean(String str) {
        return sharedPreferences.getBoolean(str, false);
    }

    public void settimer(int timer) {
        editor.putInt("timer", timer);
        editor.apply();
    }

    public int gettimer() {
        return sharedPreferences.getInt("timer", 0);
    }

    public void clearData() {
        editor.clear();
        editor.commit();
    }
}