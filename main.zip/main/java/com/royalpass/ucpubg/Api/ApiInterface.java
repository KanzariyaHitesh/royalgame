package com.royalpass.ucpubg.Api;

import com.royalpass.ucpubg.model.ResponceData;
import com.royalpass.ucpubg.model.ResponceData_ClaimBox;
import com.royalpass.ucpubg.model.ResponceData_ClaimLuckyCard;
import com.royalpass.ucpubg.model.ResponceData_LuckyBoxHistory;
import com.royalpass.ucpubg.model.ResponceData_LuckyBoxWinnerHistory;
import com.royalpass.ucpubg.model.ResponceData_LuckycardParticipate;
import com.royalpass.ucpubg.model.ResponceData_ParticipateHistory;
import com.royalpass.ucpubg.model.ResponseData_TransationRedeem;
import com.royalpass.ucpubg.model.Response_ReferralList;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiInterface {

    @FormUrlEncoded
    @POST("upgreg")
    Call<ResponceData> registerDevice(@Field("zender_nonce") String zenderNonce, @Field("sk") String sk
            , @Field("name") String Name, @Field("email") String email, @Field("invite_code") String inviteCode);

    @FormUrlEncoded
    @POST("upgecc")
    Call<ResponceData> upgecc(@Field("zender_nonce") String zenderNonce, @Field("sk") String sk
            , @Field("user_id") String userId, @Field("ucs") Float ucs);

    @FormUrlEncoded
    @POST("upgredeem")
    Call<ResponceData> upgredeem(@Field("zender_nonce") String zenderNonce, @Field("sk") String sk, @Field("user_id") String userId, @Field("pubg_id") String pubgId,
                                 @Field("option_id") String optionId);

    @FormUrlEncoded
    @POST("upgredeemlist")
    Call<ResponseData_TransationRedeem> upgredeemlist(@Field("zender_nonce") String zenderNonce, @Field("sk") String sk, @Field("user_id") String userId);

    @FormUrlEncoded
    @POST("upgclrp")
    Call<ResponceData_LuckycardParticipate> upgclrp(@Field("zender_nonce") String zenderNonce, @Field("sk") String sk, @Field("user_id") String userId);

    @FormUrlEncoded
    @POST("upgwnrph")
    Call<ResponceData_ParticipateHistory> upgwnrph(@Field("zender_nonce") String zenderNonce, @Field("sk") String sk);

    @FormUrlEncoded
    @POST("upglkcd")
    Call<ResponceData_ClaimLuckyCard> upglkcd(@Field("zender_nonce") String zenderNonce, @Field("sk") String sk, @Field("user_id") String userId);

    @FormUrlEncoded
    @POST("upgcllb")
    Call<ResponceData_ClaimBox> upgcllb(@Field("zender_nonce") String zenderNonce, @Field("sk") String sk, @Field("user_id") String userId);

    @FormUrlEncoded
    @POST("upgwnllbh")
    Call<ResponceData_LuckyBoxWinnerHistory> upgwnllbh(@Field("zender_nonce") String zenderNonce, @Field("sk") String sk, @Field("box_id") Integer boxId);

    @FormUrlEncoded
    @POST("upglbh")
    Call<ResponceData_LuckyBoxHistory> upglbh(@Field("zender_nonce") String zenderNonce, @Field("sk") String sk);

    @FormUrlEncoded
    @POST("upgrl")
    Call<Response_ReferralList> upgrl(@Field("zender_nonce") String zenderNonce, @Field("sk") String sk, @Field("user_id") String userId);

    @FormUrlEncoded
    @POST("upgep")
    Call<ResponceData> EditProfile(@Field("zender_nonce") String zenderNonce, @Field("sk") String sk, @Field("user_id") String userId, @Field("name") String Name, @Field("email") String email);

    @FormUrlEncoded
    @POST("upgdp")
    Call<ResponceData> DeleteProfile(@Field("zender_nonce") String zenderNonce, @Field("sk") String sk, @Field("user_id") String userId);
}