package com.royalpass.ucpubg.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Edit_Profile {

    @SerializedName("_id")
    @Expose
    private Id id;
    @SerializedName("invite_code")
    @Expose
    private String inviteCode;
    @SerializedName("referral_code")
    @Expose
    private String referralCode;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("ucs")
    @Expose
    private Float ucs;
    @SerializedName("paid")
    @Expose
    private Integer paid;
    @SerializedName("created_date")
    @Expose
    private Long createdDate;

    public String getId() {
        return id.$id;
    }

    public void setId(Id id) {
        this.id = id;
    }

    public String getInviteCode() {
        return inviteCode;
    }

    public void setInviteCode(String inviteCode) {
        this.inviteCode = inviteCode;
    }

    public String getReferralCode() {
        return referralCode;
    }

    public void setReferralCode(String referralCode) {
        this.referralCode = referralCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Float getUcs() {
        return ucs;
    }

    public void setUcs(Float ucs) {
        this.ucs = ucs;
    }

    public Integer getPaid() {
        return paid;
    }

    public void setPaid(Integer paid) {
        this.paid = paid;
    }

    public Long getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Long createdDate) {
        this.createdDate = createdDate;
    }

    public class Id {

        @SerializedName("$id")
        @Expose
        private String $id;

        public String get$id() {
            return $id;
        }

        public void set$id(String $id) {
            this.$id = $id;
        }

    }
}