package com.royalpass.ucpubg.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Datum_Box {
    @SerializedName("_id")
    @Expose
    private Id id;
    @SerializedName("box_id")
    @Expose
    private Integer boxId;
    @SerializedName("daily_time_stamp")
    @Expose
    private Long dailyTimeStamp;
    @SerializedName("cdt")
    @Expose
    private Long cdt;

    public String getId() {
        return id.$id;
    }

    public void setId(Id id) {
        this.id = id;
    }

    public Integer getBoxId() {
        return boxId;
    }

    public void setBoxId(Integer boxId) {
        this.boxId = boxId;
    }

    public Long getDailyTimeStamp() {
        return dailyTimeStamp;
    }

    public void setDailyTimeStamp(Long dailyTimeStamp) {
        this.dailyTimeStamp = dailyTimeStamp;
    }

    public Long getCdt() {
        return cdt;
    }

    public void setCdt(Long cdt) {
        this.cdt = cdt;
    }

    public class Id {

        @SerializedName("$id")
        @Expose
        private String $id;

        public String get$id() {
            return $id;
        }

        public void set$id(String $id) {
            this.$id = $id;
        }

    }
}
