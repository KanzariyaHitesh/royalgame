package com.royalpass.ucpubg.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CreditHistory {
    @SerializedName("_id")
    @Expose
    private Id id;
    @SerializedName("user_id")
    @Expose
    private String userId;
    @SerializedName("details")
    @Expose
    private String details;
    @SerializedName("ucs")
    @Expose
    private Float ucs;
    @SerializedName("cdt")
    @Expose
    private Long cdt;

    public String getId() {
        return id.$id;
    }

    public void setId(Id id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public Float getUcs() {
        return ucs;
    }

    public void setUcs(Float ucs) {
        this.ucs = ucs;
    }

    public Long getCdt() {
        return cdt;
    }

    public void setCdt(Long cdt) {
        this.cdt = cdt;
    }

    public class Id {

        @SerializedName("$id")
        @Expose
        private String $id;

        public String get$id() {
            return $id;
        }

        public void set$id(String $id) {
            this.$id = $id;
        }

    }
}
