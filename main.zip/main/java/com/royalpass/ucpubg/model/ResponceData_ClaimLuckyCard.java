package com.royalpass.ucpubg.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ResponceData_ClaimLuckyCard {
    @SerializedName("success")
    @Expose
    private Integer success;
    @SerializedName("msg")
    @Expose
    private String msg;
    @SerializedName("data")
    @Expose
    private Float data;
    @SerializedName("tsmp")
    @Expose
    private Tsmp tsmp;

    public Integer getSuccess() {
        return success;
    }

    public void setSuccess(Integer success) {
        this.success = success;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Float getData() {
        return data;
    }

    public void setData(Float data) {
        this.data = data;
    }

    public Tsmp getTsmp() {
        return tsmp;
    }

    public void setTsmp(Tsmp tsmp) {
        this.tsmp = tsmp;
    }

}
