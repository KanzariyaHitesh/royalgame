package com.royalpass.ucpubg.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Tsmp {

    @SerializedName("user_last_claim")
    @Expose
    private Long userLastClaim;
    @SerializedName("cdt")
    @Expose
    private Long cdt;

    public Long getUserLastClaim() {
        return userLastClaim;
    }

    public void setUserLastClaim(Long userLastClaim) {
        this.userLastClaim = userLastClaim;
    }

    public Long getCdt() {
        return cdt;
    }

    public void setCdt(Long cdt) {
        this.cdt = cdt;
    }
}