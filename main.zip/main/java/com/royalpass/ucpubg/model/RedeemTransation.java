package com.royalpass.ucpubg.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class RedeemTransation {
    @SerializedName("credit_history")
    @Expose
    private List<CreditHistory> creditHistory = null;
    @SerializedName("redeem_history")
    @Expose
    private List<RedeemHistory> redeemHistory = null;

    public List<CreditHistory> getCreditHistory() {
        return creditHistory;
    }

    public void setCreditHistory(List<CreditHistory> creditHistory) {
        this.creditHistory = creditHistory;
    }

    public List<RedeemHistory> getRedeemHistory() {
        return redeemHistory;
    }

    public void setRedeemHistory(List<RedeemHistory> redeemHistory) {
        this.redeemHistory = redeemHistory;
    }
}