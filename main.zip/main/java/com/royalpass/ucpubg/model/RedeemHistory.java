package com.royalpass.ucpubg.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class RedeemHistory {
    @SerializedName("_id")
    @Expose
    private Id_ id;
    @SerializedName("user_id")
    @Expose
    private String userId;
    @SerializedName("pubg_id")
    @Expose
    private String pubgId;
    @SerializedName("option_id")
    @Expose
    private Double optionId;
    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("created_date")
    @Expose
    private Long createdDate;

    public String getId() {
        return id.$id;
    }

    public void setId(Id_ id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPubgId() {
        return pubgId;
    }

    public void setPubgId(String pubgId) {
        this.pubgId = pubgId;
    }

    public Double getOptionId() {
        return optionId;
    }

    public void setOptionId(Double optionId) {
        this.optionId = optionId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Long getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Long createdDate) {
        this.createdDate = createdDate;
    }

    public class Id_ {

        @SerializedName("$id")
        @Expose
        private String $id;

        public String get$id() {
            return $id;
        }

        public void set$id(String $id) {
            this.$id = $id;
        }

    }
}
