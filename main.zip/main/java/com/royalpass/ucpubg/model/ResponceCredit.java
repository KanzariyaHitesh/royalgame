package com.royalpass.ucpubg.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ResponceCredit {

    @SerializedName("lucky_box_id")
    @Expose
    private Integer luckyBoxId;
    @SerializedName("bonus_ucs")
    @Expose
    private Float bonusUcs;
    @SerializedName("cdt")
    @Expose
    private Long cdt;
    @SerializedName("upd")
    @Expose
    private Integer upd;
    @SerializedName("vrs")
    @Expose
    private String vrs;
    @SerializedName("upgcc")
    @Expose
    private Integer upgcc;
    @SerializedName("upgstatus")
    @Expose
    private Integer upgstatus;
    @SerializedName("upgintru")
    @Expose
    private String upgintru;
    @SerializedName("upguintru")
    @Expose
    private String upguintru;
    @SerializedName("upginfobox")
    @Expose
    private Integer upginfobox;
    @SerializedName("upginfo")
    @Expose
    private String upginfo;
    @SerializedName("upginfobtn")
    @Expose
    private Integer upginfobtn;
    @SerializedName("upginfolink")
    @Expose
    private String upginfolink;
    @SerializedName("upginfobtntext")
    @Expose
    private String upginfobtntext;
    @SerializedName("upgnative")
    @Expose
    private String upgnative;

    public Integer getLuckyBoxId() {
        return luckyBoxId;
    }

    public void setLuckyBoxId(Integer luckyBoxId) {
        this.luckyBoxId = luckyBoxId;
    }

    public Float getBonusUcs() {
        return bonusUcs;
    }

    public void setBonusUcs(Float bonusUcs) {
        this.bonusUcs = bonusUcs;
    }

    public Long getCdt() {
        return cdt;
    }

    public void setCdt(Long cdt) {
        this.cdt = cdt;
    }

    public Integer getUpd() {
        return upd;
    }

    public void setUpd(Integer upd) {
        this.upd = upd;
    }

    public String getVrs() {
        return vrs;
    }

    public void setVrs(String vrs) {
        this.vrs = vrs;
    }

    public Integer getUpgcc() {
        return upgcc;
    }

    public void setUpgcc(Integer upgcc) {
        this.upgcc = upgcc;
    }

    public Integer getUpgstatus() {
        return upgstatus;
    }

    public void setUpgstatus(Integer upgstatus) {
        this.upgstatus = upgstatus;
    }

    public String getUpgintru() {
        return upgintru;
    }

    public void setUpgintru(String upgintru) {
        this.upgintru = upgintru;
    }

    public String getUpguintru() {
        return upguintru;
    }

    public void setUpguintru(String upguintru) {
        this.upguintru = upguintru;
    }

    public Integer getUpginfobox() {
        return upginfobox;
    }

    public void setUpginfobox(Integer upginfobox) {
        this.upginfobox = upginfobox;
    }

    public String getUpginfo() {
        return upginfo;
    }

    public void setUpginfo(String upginfo) {
        this.upginfo = upginfo;
    }

    public Integer getUpginfobtn() {
        return upginfobtn;
    }

    public void setUpginfobtn(Integer upginfobtn) {
        this.upginfobtn = upginfobtn;
    }

    public String getUpginfolink() {
        return upginfolink;
    }

    public void setUpginfolink(String upginfolink) {
        this.upginfolink = upginfolink;
    }

    public String getUpginfobtntext() {
        return upginfobtntext;
    }

    public void setUpginfobtntext(String upginfobtntext) {
        this.upginfobtntext = upginfobtntext;
    }

    public String getUpgnative() {
        return upgnative;
    }

    public void setUpgnative(String upgnative) {
        this.upgnative = upgnative;
    }
}